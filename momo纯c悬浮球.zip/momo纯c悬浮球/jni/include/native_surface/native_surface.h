//
// Created by Ssage on 2022/6/29.
//

#ifndef NATIVESURFACE_NATIVE_SURFACE_H
#define NATIVESURFACE_NATIVE_SURFACE_H
// System libs
#include <iostream>
#include <cstdlib>
#include <android/api-level.h>
// User libs
//
void* get_createNativeWindow();



#endif //NATIVESURFACE_NATIVE_SURFACE_H

