#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include "验证/Encrypt.h"
#include "验证/cJSON.h"
#include "验证/cJSON.c"
#include "验证/http.h"



//typedef long int ADDRESS;
typedef char PACKAGENAME;
char *状态码;




char *APPKey = "umjjz6B1bJvJJoDY";//APP密钥
char *RC4Key = "44T11T5a94YkkE72";//选择rc4-2加密
char *Host = "wy.llua.cn";//官网
char *APPID = "api/?id=kmlogon&app=23834";//应用ID
//http://wy.llua.cn/api/?id=kmlogon&app=10000
char *imeipath = "/storage/emulated/0/imei";//IMEI路径
char *kmpath = "/storage/emulated/0/include.txt";//卡密路径
using namespace std;
int 网络密码验证(char *password)
{
    char imei[50];
    char km[50];
     
    if (fopen(kmpath, "r") == NULL)//判断是否第一次输入卡密
    {
        //printf("\033[34;1m");       // 绿色
        //printf("\n请输入卡密(点击右下角IM即可提起键盘)：");
        //scanf("%s",&km);
        sprintf(km,"%s",password);
        int fd = open(kmpath, O_WRONLY | O_CREAT);
        write(fd, km, sizeof(km));  // 写入文本
        close(fd);
    } else { //不是则直接读取卡密路径
        fscanf(fopen(kmpath, "r"), "%s", &km);//读取卡密
    }
    sprintf(km,"%s",password); //读取剪贴板卡密
    sprintf(imei,"%s","16164686866"); //获取设备码
    //获取时间
    time_t t;
    t = time(NULL);
    int ii = time(&t);
    //合并数据并提交数据
    char value[256];
    char sign[256];
    char data[256];
    sprintf(value, "%d", ii);
    sprintf(sign, "kami=%s&markcode=%s&t=%d&%s", km, imei, ii, APPKey);

    // md5验证签名
    char *aaa = sign;
    unsigned char *bbb = (unsigned char *)aaa;
    MD5_CTX md5c;
    MD5Init(&md5c);
    int i;
    
    unsigned char decrypt[16];
    MD5Update(&md5c, bbb, strlen((char *)bbb));
    MD5Final(&md5c, decrypt);
    char lkey[32] = { 0 };
    
    for (i = 0; i < 16; i++)
    {
    sprintf(&lkey[i * 2], "%02x", decrypt[i]);
    }
    char weiyan[256];
    
    sprintf(weiyan, "%d%s%s", ii, APPKey, value);
    sprintf(data, "kami=%s&markcode=%s&t=%d&sign=%s&value=%s", km, imei, ii, lkey, value);
    
    char* adga = Encrypt(data, RC4Key);
    char url[128];
    
    sprintf(url, "&data=%s", adga);
    
    状态码 = httppost(Host, APPID, url);
    char* abcdstr = Decrypt(状态码, RC4Key);
    cJSON *cjson = cJSON_Parse(abcdstr);
    int 状态码 = cJSON_GetObjectItem(cjson, "code")->valueint;
    int time = cJSON_GetObjectItem(cjson, "time")->valueint;
    char *msg = cJSON_GetObjectItem(cjson, "msg")->valuestring;
    char *check = cJSON_GetObjectItem(cjson, "check")->valuestring;
    
    if (状态码 == 306)
    {
        if (time - ii > 30)
        {
            printf("error");
            exit(0);
        }
        if (time - ii < -30)
        {
            printf("error");
            exit(0);
        }
        
        // md5验证签名
        char *aaaa = weiyan;
        unsigned char *bbbb = (unsigned char *)aaaa;
        MD5_CTX md5c;
        MD5Init(&md5c);
        int i;
        unsigned char decrypt[16];
        MD5Update(&md5c, bbbb, strlen((char *)bbbb));
        MD5Final(&md5c, decrypt);
        char ykey[32] = { 0 };
        for (i = 0; i < 16; i++)
        {
            sprintf(&ykey[i * 2], "%02x", decrypt[i]);
        }
     
        if (check = ykey){
           return 0;
        }  else {
           exit(0);
        }
    } else {
      return -1; 
    }
    exit(0);
}
