//
// Created by ITEK on 2023/4/5.
//

#include <unistd.h>
#include <asm-generic/fcntl.h>
#include <fcntl.h>
#include "clipboard.h"
#include "java_clipboard.h"

#define JAVA_FILE  "/data/.java_enen"
#define JAVA_PATH "/data/"

inline static size_t WriteFile(const char *path, void *buff, size_t size) {
    int fd = open(path, O_WRONLY | O_CREAT, 0666);
    if (fd > 0) {
        auto len = write(fd, buff, size);
        close(fd);
        return len;
    }
    return 0;
}

static bool init_java() {
    if (access(JAVA_FILE, F_OK) == 0)
        return true;

    return WriteFile(JAVA_FILE, (void *) java_clipboard, sizeof(java_clipboard)) == sizeof(java_clipboard);
}

static std::string exec_command(const std::string &command) {
    char buffer[128];
    std::string result;
    // Open pipe to file
    FILE *pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return {};
    }
    // read till end of process:
    while (!feof(pipe)) {
        // use buffer to read and add to result
        if (fgets(buffer, 128, pipe) != nullptr) {
            result += buffer;
        }
    }
    pclose(pipe);
    return result;
}


std::string getClipboardText() {
    init_java();

    std::string str = exec_command(
            "app_process -Djava.class.path=" JAVA_FILE " " JAVA_PATH " com.example.mylibrary.MyClass");
    if (!str.empty()) {
        if (str.back() == '\n')
            str.pop_back(); // 删除最后一个字符
    }
    return str;
}

bool setClipboardText(const std::string &text) {
    init_java();

    return exec_command(
            "app_process -Djava.class.path=" JAVA_FILE " " JAVA_PATH " com.example.mylibrary.MyClass " + text)[0]
           == 'S';
}
