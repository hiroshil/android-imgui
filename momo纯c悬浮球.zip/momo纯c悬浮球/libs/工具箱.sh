cp arm64-v8a/GeamImGui ... /data
chmod 777 /data/GeamImGui*
/data/GeamImGui
