#include <draw.h>
#include "include.h"


void *handle;// 动态库方案
EGLDisplay display = EGL_NO_DISPLAY;
EGLConfig config;
EGLSurface surface = EGL_NO_SURFACE;
ANativeWindow *native_window;
ANativeWindow *(*createNativeWindow)(const char *surface_name, uint32_t screen_width, uint32_t screen_height, bool author);
EGLContext context = EGL_NO_CONTEXT;

Screen full_screen;
int Orientation = 0;
int screen_x = 0, screen_y = 0;
int init_screen_x = 0, init_screen_y = 0;
bool g_Initialized = false;
int FPS = 144;
timer FPS限制;
float FPF显示 = 0;
ImColor BoxColor = {1.0f,0.0f,0.0f,1.0f};
ImColor BoneColor = ImColor(255,0,0,255);
ImColor BotBoxColor = ImColor(255,255,255,255);
ImColor BotBoneColor = ImColor(255,255,255,255);
ImColor LineColor = ImColor(255,0,0,255);
ImColor BotLineColor = ImColor(255,255,255,255);

string exec(string command) {
    char buffer[128];
    string result = "";
    // Open pipe to file
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return "popen failed!";
    }
    // read till end of process:
    while (!feof(pipe)) {
        // use buffer to read and add to result
        if (fgets(buffer, 128, pipe) != nullptr){
            result += buffer;
        }
    }
    pclose(pipe);
    return result;
}

int init_egl(int _screen_x, int _screen_y, bool log){
    void* sy = get_createNativeWindow(); // 适配9-13安卓版本
    createNativeWindow = (ANativeWindow *(*)(const char *, uint32_t, uint32_t, bool))(sy);
    native_window = createNativeWindow("Ssage", _screen_x, _screen_y, false);
    ANativeWindow_acquire(native_window);
    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        printf("eglGetDisplay error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglGetDisplay ok\n");
    }
    if (eglInitialize(display, 0, 0) != EGL_TRUE) {
        printf("eglInitialize error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglInitialize ok\n");
    }
    EGLint num_config = 0;
    const EGLint attribList[] = {
            EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
            EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
            EGL_BLUE_SIZE, 5,   //-->delete
            EGL_GREEN_SIZE, 6,  //-->delete
            EGL_RED_SIZE, 5,    //-->delete
            EGL_BUFFER_SIZE, 32,  //-->new field
            EGL_DEPTH_SIZE, 16,
            EGL_STENCIL_SIZE, 8,
            EGL_NONE
    };
    if (eglChooseConfig(display, attribList, nullptr, 0, &num_config) != EGL_TRUE) {
        printf("eglChooseConfig  error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("num_config=%d\n", num_config);
    }
    if (!eglChooseConfig(display, attribList, &config, 1, &num_config)) {
        printf("eglChooseConfig  error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglChooseConfig ok\n");
    }
    EGLint egl_format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(native_window, 0, 0, egl_format);
    const EGLint attrib_list[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    context = eglCreateContext(display, config, EGL_NO_CONTEXT, attrib_list);
    if (context == EGL_NO_CONTEXT) {
        printf("eglCreateContext  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglCreateContext ok\n");
    }
    surface = eglCreateWindowSurface(display, config, native_window, nullptr);
    if (surface == EGL_NO_SURFACE) {
        printf("eglCreateWindowSurface  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglCreateWindowSurface ok\n");
    }
    if (!eglMakeCurrent(display, surface, surface, context)) {
        printf("eglMakeCurrent  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglMakeCurrent ok\n");
    }
    return 1;
}

void screen_config(){
    std::string window_size = exec("wm size");
    sscanf(window_size.c_str(),"Physical size: %dx%d",&screen_x, &screen_y);
    full_screen.ScreenX = screen_x;
    full_screen.ScreenY = screen_y;
    std::thread *orithread = new std::thread([&] {
        while(true){
            Orientation = atoi(exec("dumpsys input | grep SurfaceOrientation | awk '{print $2}' | head -n 1").c_str());
            if(Orientation == 0 || Orientation == 2){
                screen_x = full_screen.ScreenX;
                screen_y = full_screen.ScreenY;
            }
            if(Orientation == 1 || Orientation == 3){
                screen_x = full_screen.ScreenY;
                screen_y = full_screen.ScreenX;
            }
            std::this_thread::sleep_for(0.5s);
        }
    });
    orithread->detach();
}

void ImGuiMenustyle()
{
	NumIo[1] = 300.0f;                                                  
    NumIo[2] = 400.0f;
 	NumIo[3] = 340.0f;
    NumIo[4] = 20.0f;
  	NumIo[6] = 1500.0f;
    NumIo[5] = 650.0f;
    NumIo[7] = 600.0f;
    NumIo[8] = 2.0f;
    NumIo[9] = 10.0f; 
	NumIo[11] = 1000.0f;
	NumIo[13] = 0.0f;
	NumIo[14] = 105.0f;
	NumIo[15] = 105.0f;
}


void ImGui_init(){
    if (g_Initialized){
        return;
    }
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = NULL;
    ImGui::StyleColorsDark();
    ImGui_ImplAndroid_Init(native_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    ImFontConfig font_cfg;
    font_cfg.SizePixels = 22.0f;
    io.Fonts->AddFontFromMemoryTTF((void *) font_v, font_v_size, 28.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
    io.Fonts->AddFontDefault(&font_cfg);
    ImGui::GetStyle().ScaleAllSizes(3.0f);
    g_Initialized = true;
}






void DrawInit()
{
pid = getPID("com.tencent.ig");
py = screen_x / 2;  
px = screen_y / 2; 
libbase = get_module_base(pid, "libUE4.so");
Matrix = getZZ(getZZ(libbase + 0xC2D9148) + 0x20) + 0x270;
ImGuiMenustyle();

}

struct AimStruct
{
    Vector3A ObjAim;  
	Vector3A MyObjAim;
    Vector3A AimMovement;  
    float ScreenDistance = 0;
    float WodDistance = 0; 
}Aim[100];

int findminat()
{
    float min = NumIo[3];
    int minAt = 999;
    for (int i = 0; i < MaxPlayerCount; i++)
    {
        if (Aim[i].ScreenDistance < min && Aim[i].ScreenDistance != 0)
        {
            min = Aim[i].ScreenDistance;
            minAt = i;
        }
    }
    if (minAt == 999)
    {
        Gmin = -1;
        return -1;
    }
    Gmin = minAt;   
    WorldDistance = Aim[minAt].WodDistance;
    return minAt;
}


float GetPitch(float Fov) 
{
    if (Fov > 75 && Fov <= 130)          // 不开镜
    {
        return (0.7f/30)*NumIo[4];
    }
    else if (Fov == 70 || Fov == 75)    // 机瞄 ，侧瞄
    {     
        return (1.8f/30)*NumIo[4];       
    }
    else if (Fov == 55 || Fov == 60)    // 红点 ，全息
    {
        return (1.8f/30)*NumIo[4];
    }   
    else if ((int)Fov == 44)    // 2倍
    {
        return (5.3f/30)*NumIo[4];
    }
    else if ((int)Fov == 26)    // 3倍
    {
        return (7.2f/30)*NumIo[4];
    }
    else if ((int)Fov == 20)    // 4倍
    {
        return (8.6f/30)*NumIo[4];
    }
    else if ((int)Fov == 13)    // 6倍
    {       
        return (14.1f/30)*NumIo[4];
    }
	return (2.5f/30)*NumIo[4];   // 8倍
}

void AimBotAuto(ImDrawList *Draw)
{   
    bool isDown = false;
    // 是否按下触摸
    double leenx = NumIo[14];
    // x轴速度
    double leeny = NumIo[15];
    // y轴速度     
    double de = 1.5f;
    // 顶部不可触摸区域
   
    double tx = 0, ty = 0;
    // 触摸点位置

    float SpeedMin = 2.0f;
    // 临时触摸速度

    double w = 0.0f, h = 0.0f, cmp = 0.0f;
    // 宽度 高度 正切

    double ScreenX = screen_x, ScreenY = screen_y;
    // 分辨率(竖屏)PS:滑屏用的坐标是竖屏状态下的

    double ScrXH = ScreenX / 2.0f;
    // 一半屏幕X

    double ScrYH = ScreenY / 2.0f;
    // 一半屏幕X

    static float TargetX = 0;
    static float TargetY = 0;
    // 触摸目标位置
    
    Vector3A obj;
    
    float NowCoor[3];
   
	Touch_Init(&screen_x,&screen_y);	
	
    while (1)
    {
        
        if (!DrawIo[20])
        {           
            if (isDown == true)
            {
                tx = NumIo[5], ty = NumIo[6];
                // 恢复变量 
                Touch_Up(8);
                // 抬起
                isDown = false;
            }
            usleep(NumIo[9] * 1000);
            continue;
        }
        
        findminat();
        // 获取目标

        if (Gmin == -1)
        {          
            if (isDown == true)
            {
                tx = NumIo[5], ty = NumIo[6];
                // 恢复变量 
                Touch_Up(8);
                // 抬起
                isDown = false;
            }
            usleep(NumIo[9] * 1000);
            continue;
        }
		
	
		
		
        float ToReticleDistance = Aim[Gmin].ScreenDistance;              
        float FlyTime = WorldDistance / NumIo[11];
        float DropM = 500.0f * FlyTime * FlyTime;
		//
		float Fov = getFloat(getZZ(getZZ(MySelf  + 0x430) + 0x490) + 0x410);
        int Firing = getDword(MySelf + 0x1560);
        int Aiming = getDword(MySelf + 0xFA8);
		
		float yq = GetPitch(Fov);
		
	    NowCoor[0] = Aim[Gmin].ObjAim.X;
        NowCoor[1] = Aim[Gmin].ObjAim.Y;
        NowCoor[2] = Aim[Gmin].ObjAim.Z;
        obj.X = NowCoor[0] + (FlyTime /0.2 * diff[0]);
        obj.Y = NowCoor[1] + (FlyTime /0.2 * diff[1]);
        obj.Z = NowCoor[2] + (FlyTime /0.2 * diff[2]) + DropM;
        float cameras = matrix[3] * obj.X + matrix[7] * obj.Y + matrix[11] * obj.Z + matrix[15];        
        
		
        Vector2A vpvp = WorldToScreen(obj,matrix,cameras);             
		
		float AimDs = sqrt(pow(px - vpvp.X, 2) + pow(py - vpvp.Y, 2));
        zm_y = vpvp.X;     
        zm_x = ScreenX - vpvp.Y;        
		
        if (zm_x <= 0 || zm_x >= ScreenX || zm_y <= 0 || zm_y >= ScreenY)
        {          
            if (isDown == true)
            {
                tx = NumIo[5], ty = NumIo[6];
                // 恢复变量 
                Touch_Up(8);
                // 抬起
                isDown = false;
            }
            usleep(NumIo[9] * 1000);
            continue;
        }

        if (ToReticleDistance <= NumIo[3])
        {                          
        switch ((int)NumIo[0])
            {
                case 0:
                    if (Firing != 1)
                    {
                        if (isDown == true)
                        {
                        
                            tx = NumIo[5], ty = NumIo[6];
                            // 恢复变量
                            Touch_Up(8);
                            isDown = false;
                        }                      
                        usleep(NumIo[9] * 1000);
                        continue;
                    }
                break;
                case 1:
                    if (Aiming != 256)
                    {
                        if (isDown == true)
                        {
                            tx = NumIo[5], ty = NumIo[6];
                            // 恢复变量
                            Touch_Up(8);
                            isDown = false;
                        }
                        usleep(NumIo[9] * 1000);
                        continue;
                    }
                break;
                case 2:
                    if (Firing != 1 && Aiming != 256)
                    {
                        if (isDown == true)
                        {
                            tx = NumIo[5], ty = NumIo[6];
                            // 恢复变量
                            Touch_Up(8);
                            isDown = false;
                        }
                        usleep(NumIo[9] * 1000);
                        continue;
                    }
                break;
            }         
                
                   
            if (isDown == false)
            {
				if (NumIo[10] == 0.0f)
                Touch_Down(8,(int)tx, (int)ty);
                isDown = true;
            }
			
			float Aimspeace = NumIo[4];
			if (AimDs < 1)
				Aimspeace = NumIo[4] / 0.09;		
			else if (AimDs < 2)
				Aimspeace = NumIo[4] / 0.11;		
			else if (AimDs < 3)
				Aimspeace = NumIo[4] / 0.12;	
			else if (AimDs < 5)
				Aimspeace = NumIo[4] / 0.15;		
			else if (AimDs < 10)
				Aimspeace = NumIo[4] / 0.25;		
			else if (AimDs < 15)
				Aimspeace = NumIo[4] / 0.4;		
			else if (AimDs < 20)
				Aimspeace = NumIo[4] / 0.5;
			else if (AimDs < 25)
				Aimspeace = NumIo[4] / 0.6;		
			else if (AimDs < 30)
				Aimspeace = NumIo[4] / 0.7;
	        else if (AimDs < 40)
				Aimspeace = NumIo[4] / 0.75;
			else if (AimDs < 50)
				Aimspeace = NumIo[4] / 0.8;
			else if (AimDs < 60)
				Aimspeace = NumIo[4] / 0.85;
			else if (AimDs < 70)
				Aimspeace = NumIo[4] / 0.9;
			else if (AimDs < 80)
				Aimspeace = NumIo[4] / 0.95;	
			else if (AimDs < 90)
				Aimspeace = NumIo[4] / 1.0;		
			else if (AimDs < 100)
				Aimspeace = NumIo[4] / 1.05;
			else if (AimDs < 150)
				Aimspeace = NumIo[4] / 1.25;
			else if (AimDs < 200)
				Aimspeace = NumIo[4] / 1.5;
			else
				Aimspeace = NumIo[4] / 1.55;					

            if (zm_x > ScrXH)
            {
                TargetX = -(ScrXH - zm_x);
                TargetX /= Aimspeace;                                       
                if (TargetX + ScrXH > ScrXH * 2)
                    TargetX = 0;
            }
            if (zm_x < ScrXH)
            {
                TargetX = zm_x - ScrXH;
                TargetX /= Aimspeace;             
                if (TargetX + ScrXH < 0)
                    TargetX = 0;
            }
            if (zm_y > ScrYH)
            {
                TargetY = -(ScrYH - zm_y);
                TargetY /= Aimspeace;              
                if (TargetY + ScrYH > ScrYH * 2)
                    TargetY = 0;
            }
            if (zm_y < ScrYH)
            {
                TargetY = zm_y - ScrYH;
                TargetY /= Aimspeace;              
                if (TargetY + ScrYH < 0)
                    TargetY = 0;
            }
            
            if (TargetY >= 35 || TargetX >= 35 || TargetY <= -35 || TargetX <= -35)
            {
                if (isDown == true)
                {
                    tx = NumIo[5], ty = NumIo[6];
                    // 恢复变量
                    Touch_Up(8);
                    isDown = false;
                }
                usleep(NumIo[9] * 1000);
                continue;
            }           		
            tx += TargetX;
            ty += TargetY;		
			if(Firing == 1)
				tx -= yq;
            if (tx >= NumIo[5] + NumIo[7] || tx <= NumIo[5] - NumIo[7]
                || ty >= NumIo[6] + NumIo[7] || ty <= NumIo[6] - NumIo[7])
            {
                // 只要滑屏达到了边界，直接还原至中心
                tx = NumIo[5], ty = NumIo[6];
                // 恢复变量
                Touch_Up(8);
                // 抬起            
				if (NumIo[10] == 0.0f)
                	Touch_Down(8,(int)tx, (int)ty);
            }         		           
			if (NumIo[10] == 0.0f)
           		Touch_Move(8,(int)tx, (int)ty);
        }
        else
        {          
            if (isDown == true)
            {
                tx = NumIo[5], ty = NumIo[6];
                // 恢复变量 
                Touch_Up(8);
                // 抬起
                isDown = false;
            }
        }
        usleep(NumIo[9] * 1000);
    }
}



void DrawPlayer(ImDrawList *draw)
{
    float top,right,left,bottom,x1,top1;   
    // 自瞄圈圈
    if (DrawIo[20])       
    {         
        draw->AddCircle({px, py}, NumIo[3],ImColor(255,255,255,255),0,2.5f);     
    }
       
	
    if (DrawIo[21])
    {	
        draw->AddRectFilled({0,0}, {px*2, py*2},ImColor(0,0,0,110));
        std::string ssf;  
        ssf += "触摸位置";
        auto textSize = ImGui::CalcTextSize(ssf.c_str(), 0, 25);
        draw->AddRectFilled({NumIo[6] - NumIo[7]/2, py*2 - NumIo[5] + NumIo[7]/2}, {NumIo[6] + NumIo[7]/2, py*2 - NumIo[5] - NumIo[7]/2},ImColor(255,0,0,120)); 
		draw->AddText(NULL,32,{NumIo[6] - (textSize.x / 2),py*2 - NumIo[5]},ImColor(255,255,255),ssf.c_str());                                                   
    }  
    
    Uworld = getZZ(getZZ(libbase + 0xBEBA1D8));
    Uleve = getZZ(Uworld+ 0x20);
    Arrayaddr = getZZ(Uleve + 0xA0); 
    Count = getDword(Uleve + 0xA8);
    
	MySelf = Uworld;
	Myteam = getDword(MySelf + 0x8F8); 



	
    memset(matrix, 0, 16);
    vm_readv(Matrix, matrix, 16 * 4);
    
    PlayerCount = 0; 
    BotCount = 0;
    AimCount = 0;
    AimObjCount = 0;
    
    for (int i = 0; i <800; i++)
    {
        Objaddr = getZZ(Arrayaddr + 8 * i);  
		
		if(Objaddr == 0)
		{
		continue;
		}
		
		int TeamID = getDword(Objaddr + 0x8F8);
        float Health = getFloat(Objaddr + 0xD18);
	    float NOTHealth = getFloat(Objaddr + 0xD1C);
	    int isBot = getDword(Objaddr + 0x990);
	    
	        if (Myteam == TeamID || TeamID == 0)
            {
                continue;
            }
            
            if (getDword(Objaddr + 0xD34) != 0)
            {
              continue;
            }
            
            if (getFloat(Objaddr + 0x2658) != 479.5 || Health <=0)
            {
                continue;
            }
		
					
        
        Vector3A Z;
        vm_readv(getZZ(MySelf + 0x1B0) + 0x1B0, &Z, sizeof(Z)); 
        
        Vector3A D;
        vm_readv(getZZ(Objaddr + 0x1B0) + 0x1B0, &D, sizeof(D)); 
        
       
        camera = matrix[3] * D.X + matrix[7] * D.Y + matrix[11] * D.Z + matrix[15];

        r_x =
            px + (matrix[0] * D.X + matrix[4] * D.Y + matrix[8] * D.Z +
                      matrix[12]) / camera * px;
        r_y =
            py - (matrix[1] * D.X + matrix[5] * D.Y + matrix[9] * (D.Z - 5) +
                      matrix[13]) / camera * py;
        r_w =
            py - (matrix[1] * D.X + matrix[5] * D.Y + matrix[9] * (D.Z + 205) +
                      matrix[13]) / camera * py;
      
            float X = r_x - (r_y - r_w) / 4;
            float Y = r_y;
            float W = (r_y - r_w) / 2;
			
			float MIDDLE = X + W / 2;
         	float BOTTOM = Y + W;
		 	float TOP = Y - W;
			
			
            float Distance = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2) + pow(D.Z - Z.Z, 2)) * 0.01;
			
            left = (X + W / 2) - W / 2.6f;
            right = X + W / 1.12f;
			
			if (Distance > 550)
            {
             continue;
            }
			
			
     
        
			
		    Vector3A Movement;   
            vm_readv(getZZ(Objaddr + 0x1A78) + 0x124, &Movement, sizeof(Movement));
            
     
      

            getUTF8(PlayerName, getZZ(Objaddr + 0x8B0));

			Mesh = getZZ(Objaddr + 0x458);
			
            human = Mesh + 0x1A0;
			
            Bone = getZZ(Mesh + 0x7A8) + 0x30;
		
            FTransform meshtrans = getBone(human);
		    FMatrix c2wMatrix = TransformToMatrix(meshtrans);			
		    
			// 头部
		    FTransform headtrans = getBone(Bone + 5 * 48);
		    FMatrix boneMatrix = TransformToMatrix(headtrans);
		    Vector3A relLocation = MarixToVector(MatrixMulti(boneMatrix, c2wMatrix));
		    relLocation.Z += 7;	// 脖子长度
		    Head = WorldToScreen(relLocation, matrix, camera);	
			
			// 胸部
		    FTransform chesttrans = getBone(Bone + 4 * 48);
		    FMatrix boneMatrix1 = TransformToMatrix(chesttrans);
		    Vector3A relLocation1 = MarixToVector(MatrixMulti(boneMatrix1, c2wMatrix));
		    Chest = WorldToScreen(relLocation1, matrix, camera);		
			
		    // 盆骨
		    FTransform pelvistrans = getBone(Bone + 11 * 48);
		    FMatrix boneMatrix2 = TransformToMatrix(pelvistrans);
	    	Vector3A LrelLocation1 = MarixToVector(MatrixMulti(boneMatrix2, c2wMatrix));
		    Pelvis = WorldToScreen(LrelLocation1, matrix, camera);			
		    
			// 左肩膀
		    FTransform lshtrans = getBone(Bone + 32 * 48);
		    FMatrix boneMatrix3 = TransformToMatrix(lshtrans);
	     	Vector3A relLocation2 = MarixToVector(MatrixMulti(boneMatrix3, c2wMatrix));
		    Left_Shoulder = WorldToScreen(relLocation2, matrix, camera);		
		   
			// 右肩膀
	        FTransform rshtrans = getBone(Bone + 12 * 48);
		    FMatrix boneMatrix4 = TransformToMatrix(rshtrans);
		    Vector3A relLocation3 = MarixToVector(MatrixMulti(boneMatrix4, c2wMatrix));
		    Right_Shoulder = WorldToScreen(relLocation3, matrix, camera);		
		   
			// 左手肘
		    FTransform lelbtrans = getBone(Bone + 33 * 48);
		    FMatrix boneMatrix5 = TransformToMatrix(lelbtrans);
		    Vector3A relLocation4 = MarixToVector(MatrixMulti(boneMatrix5, c2wMatrix));
		    Left_Elbow = WorldToScreen(relLocation4, matrix, camera);	
		    
			// 右手肘
		    FTransform relbtrans = getBone(Bone + 63 * 48);
		    FMatrix boneMatrix6 = TransformToMatrix(relbtrans);
		    Vector3A relLocation5 = MarixToVector(MatrixMulti(boneMatrix6, c2wMatrix));
		    Right_Elbow = WorldToScreen(relLocation5, matrix, camera);	
		 
			// 左手腕
		    FTransform lwtrans = getBone(Bone + 62 * 48);
		    FMatrix boneMatrix7 = TransformToMatrix(lwtrans);
		    Vector3A relLocation6 = MarixToVector(MatrixMulti(boneMatrix7, c2wMatrix));
		    Left_Wrist = WorldToScreen(relLocation6, matrix, camera);		
		
		    // 右手腕
		    FTransform rwtrans = getBone(Bone + 1 * 48);
		    FMatrix boneMatrix8 = TransformToMatrix(rwtrans);
		    Vector3A relLocation7 = MarixToVector(MatrixMulti(boneMatrix8, c2wMatrix));
		    Right_Wrist = WorldToScreen(relLocation7, matrix, camera);		
		
		    // 左大腿
		    FTransform Llshtrans = getBone(Bone + 52 * 48);
		    FMatrix boneMatrix9 = TransformToMatrix(Llshtrans);
		    Vector3A LrelLocation2 = MarixToVector(MatrixMulti(boneMatrix9, c2wMatrix));
		    Left_Thigh = WorldToScreen(LrelLocation2, matrix, camera);		
		
		    // 右大腿
		    FTransform Lrshtrans = getBone(Bone + 56 * 48);
		    FMatrix boneMatrix10 = TransformToMatrix(Lrshtrans);
		    Vector3A LrelLocation3 = MarixToVector(MatrixMulti(boneMatrix10, c2wMatrix));
		    Right_Thigh = WorldToScreen(LrelLocation3, matrix, camera);
		
		    // 左膝盖
		    FTransform Llelbtrans = getBone(Bone + 53 * 48);
		    FMatrix boneMatrix11 = TransformToMatrix(Llelbtrans);
		    Vector3A LrelLocation4 = MarixToVector(MatrixMulti(boneMatrix11, c2wMatrix));
		    Left_Knee = WorldToScreen(LrelLocation4, matrix, camera);		
		
		    // 右膝盖
		    FTransform Lrelbtrans = getBone(Bone + 57 * 48);
		    FMatrix boneMatrix12 = TransformToMatrix(Lrelbtrans);
		    Vector3A LrelLocation5 = MarixToVector(MatrixMulti(boneMatrix12, c2wMatrix));
	    	Right_Knee = WorldToScreen(LrelLocation5, matrix, camera);
		
		    // 左脚腕
		    FTransform Llwtrans = getBone(Bone + 54 * 48);
		    FMatrix boneMatrix13 = TransformToMatrix(Llwtrans);
		    Vector3A LrelLocation6 = MarixToVector(MatrixMulti(boneMatrix13, c2wMatrix));
		    Left_Ankle = WorldToScreen(LrelLocation6, matrix, camera);
		
		    // 右脚腕
		    FTransform Lrwtrans = getBone(Bone + 58 * 48);
		    FMatrix boneMatrix14 = TransformToMatrix(Lrwtrans);
		    Vector3A LrelLocation7 = MarixToVector(MatrixMulti(boneMatrix14, c2wMatrix));
		    Right_Ankle = WorldToScreen(LrelLocation7, matrix, camera);           					
		    
			if (LrelLocation6.Z < LrelLocation7.Z)
		    {
		    LrelLocation7.Z = LrelLocation6.Z;
		    }
            
            
            top1 = Pelvis.Y - Head.Y;
            top = Pelvis.Y - top1 - W / 5;    
            
            if (Left_Ankle.Y < Right_Ankle.Y) {
                bottom = Right_Ankle.Y + W / 10;
            } else {
                bottom = Left_Ankle.Y  + W / 10;
            }
            
            if (W > 0){
            
			
			Aim[AimCount].WodDistance = Distance;
			Aim[AimCount].AimMovement = Movement;
			if (NumIo[8] == 1.0){
                Aim[AimCount].ObjAim = relLocation;                            
                Aim[AimCount].ScreenDistance = sqrt(pow(px - Head.X, 2) + pow(py - Head.Y, 2));
            }else if (NumIo[8] == 2.0 || NumIo[8] == 0.0){                                 
                Aim[AimCount].ObjAim = relLocation1;                            
                Aim[AimCount].ScreenDistance = sqrt(pow(px - Chest.X, 2) + pow(py - Chest.Y, 2));
            }else if (NumIo[8] == 3.0){                                 
                Aim[AimCount].ObjAim = LrelLocation1;                                                 
                Aim[AimCount].ScreenDistance = sqrt(pow(px - Pelvis.X, 2) + pow(py - Pelvis.Y, 2));
            }else{
                Aim[AimCount].ObjAim = relLocation1;                            
                Aim[AimCount].ScreenDistance = sqrt(pow(px - Chest.X, 2) + pow(py - Chest.Y, 2));
            }
			AimCount++;
		}
			
			
            if(W > 0)
            {    
                if (DrawIo[8])
                {
				std::string s;
           		s += std::to_string((int)Distance);
          		s += "M";
           		auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 28.f);
           		ImGui::GetForegroundDrawList()->AddText(NULL, 28.f, {MIDDLE - 20, BOTTOM + 10}, ImColor(248,248,255), s.c_str());
                }
				
                if (DrawIo[1])
                {
                // 方框
                if (isBot == 1)
                    {                
                        	draw->AddRect({X, TOP}, {X + W, BOTTOM}, BotBoxColor, 0, 0, 1.3f);
                    }else{                       
                        	draw->AddRect({X, TOP}, {X + W, BOTTOM},BoxColor, {0}, 0, {1.5});			
                    } 
				}
     
                if (DrawIo[2])
                {
                // 射线                
                if (isBot == 1)
                    {
                        draw->AddLine({px , 150}, {Head.X, TOP - 55}, BotLineColor, {1.5});  
                    }else{
                        draw->AddLine({px , 150}, {Head.X, TOP - 55}, LineColor, {1.5});
                    }
				}
                
                if (DrawIo[3])
                {
				//骨骼
                if (isBot == 1)
                    {
                        draw->AddCircle({Head.X , Head.Y}, W/5, BotBoneColor, 0);    
                        draw->AddLine({Head.X, Head.Y}, {Chest.X, Chest.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Chest.X, Chest.Y}, {Pelvis.X, Pelvis.Y},BotBoneColor,{2.5});
                        draw->AddLine({Chest.X, Chest.Y}, {Left_Shoulder.X,Left_Shoulder.Y},BotBoneColor,{2.5});
                        draw->AddLine({Chest.X, Chest.Y}, {Right_Shoulder.X,Right_Shoulder.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Left_Shoulder.X, Left_Shoulder.Y}, {Left_Elbow.X,Left_Elbow.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Right_Shoulder.X, Right_Shoulder.Y},{Right_Elbow.X, Right_Elbow.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Left_Elbow.X, Left_Elbow.Y}, {Left_Wrist.X,Left_Wrist.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Right_Elbow.X, Right_Elbow.Y}, {Right_Wrist.X,Right_Wrist.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Pelvis.X, Pelvis.Y}, {Left_Thigh.X, Left_Thigh.Y},BotBoneColor,{2.5});
                        draw->AddLine({Pelvis.X, Pelvis.Y}, {Right_Thigh.X,Right_Thigh.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Left_Thigh.X, Left_Thigh.Y}, {Left_Knee.X,Left_Knee.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Right_Thigh.X, Right_Thigh.Y}, {Right_Knee.X,Right_Knee.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Left_Knee.X, Left_Knee.Y}, {Left_Ankle.X,Left_Ankle.Y}, BotBoneColor,{2.5});
                        draw->AddLine({Right_Knee.X, Right_Knee.Y}, {Right_Ankle.X,Right_Ankle.Y}, BotBoneColor,{2.5});           
                    }else{
                        draw->AddCircle({Head.X , Head.Y}, W/5, BoneColor, 0);    
                        draw->AddLine({Head.X, Head.Y}, {Chest.X, Chest.Y}, BoneColor,{2.5});
                        draw->AddLine({Chest.X, Chest.Y}, {Pelvis.X, Pelvis.Y},BoneColor,{2.5});
                        draw->AddLine({Chest.X, Chest.Y}, {Left_Shoulder.X,Left_Shoulder.Y},BoneColor,{2.5});
                        draw->AddLine({Chest.X, Chest.Y}, {Right_Shoulder.X,Right_Shoulder.Y}, BoneColor,{2.5});
                        draw->AddLine({Left_Shoulder.X, Left_Shoulder.Y}, {Left_Elbow.X,Left_Elbow.Y}, BoneColor,{2.5});
                        draw->AddLine({Right_Shoulder.X, Right_Shoulder.Y},{Right_Elbow.X, Right_Elbow.Y}, BoneColor,{2.5});
                        draw->AddLine({Left_Elbow.X, Left_Elbow.Y}, {Left_Wrist.X,Left_Wrist.Y}, BoneColor,{2.5});
                        draw->AddLine({Right_Elbow.X, Right_Elbow.Y}, {Right_Wrist.X,Right_Wrist.Y}, BoneColor,{2.5});
                        draw->AddLine({Pelvis.X, Pelvis.Y}, {Left_Thigh.X, Left_Thigh.Y},BoneColor,{2.5});
                        draw->AddLine({Pelvis.X, Pelvis.Y}, {Right_Thigh.X,Right_Thigh.Y}, BoneColor,{2.5});
                        draw->AddLine({Left_Thigh.X, Left_Thigh.Y}, {Left_Knee.X,Left_Knee.Y}, BoneColor,{2.5});
                        draw->AddLine({Right_Thigh.X, Right_Thigh.Y}, {Right_Knee.X,Right_Knee.Y}, BoneColor,{2.5});
                        draw->AddLine({Left_Knee.X, Left_Knee.Y}, {Left_Ankle.X,Left_Ankle.Y}, BoneColor,{2.5});
                        draw->AddLine({Right_Knee.X, Right_Knee.Y}, {Right_Ankle.X,Right_Ankle.Y}, BoneColor,{2.5});              
                    }
				}
                
                if (DrawIo[6]){               
                ImGui::GetForegroundDrawList()->AddRect({MIDDLE - 60, TOP - 31}, {MIDDLE + 60, TOP - 20}, ImColor(255, 255, 255),2.5f,0,2.8f);
                if (Health > 100)
                {
                ImGui::GetForegroundDrawList()->AddRectFilled({MIDDLE - 60, TOP - 31}, {MIDDLE + 60, TOP - 20}, ImColor(255,0,0),2.5f,0);
                }
                else if (Health > 0 && Health <= 100)
                {
                ImGui::GetForegroundDrawList()->AddRectFilled({MIDDLE - 60, TOP - 29}, {MIDDLE - 60 + Health * 1.2f, TOP - 22}, ImColor(255,0,0),2.5f,0);
                       
              		}
				}                                                                             
                
				if (DrawIo[4])
                {
				std::string s;
				s += "[";
           		s += std::to_string(TeamID);
           		s += "]";
           		s += " ";
           		if (isBot == 1)
           		{
           		s += "BOT";
           		}
           		else
           		{
		   		s += PlayerName;
		   		}
          		auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 23.f);
           		ImGui::GetForegroundDrawList()->AddText(NULL, 23.f, {MIDDLE - 60, TOP - 55}, ImColor(255,255,0), s.c_str());
                }                                                                          
            }        
			MaxPlayerCount = AimCount;
			PlayerCount++;
                 
    }



    
    MaxPlayerCount = AimCount;
    if (PlayerCount == 0)
    {
        draw->AddRectFilled({px - 50, 100 - 30}, {px + 50, 100 + 30}, ImColor(0,255,0),{40});
        std::string str1;                  
        str1 += "安全";                   
        auto textSize = ImGui::CalcTextSize(str1.c_str(), 0, 25);
      //  float aa = Health*3.6;
        draw->AddText(NULL,30,{px + 3 - (textSize.x / 2), 85}, ImColor(255,255,255), str1.c_str());                            
    }else if (PlayerCount <= 8){
        draw->AddRectFilled({px - 50, 100 - 30}, {px + 50, 100 + 30}, ImColor(255,185,30),{40});
        std::string str1;                  
        str1 += std::to_string((int)PlayerCount);                   
        auto textSize = ImGui::CalcTextSize(str1.c_str(), 0, 25);
  //      float aa = Health*3.6;
        draw->AddText(NULL,30,{px + 3 - (textSize.x / 2), 85}, ImColor(255,255,255), str1.c_str());                            
    }else{
        draw->AddRectFilled({px - 50, 100 - 30}, {px + 50, 100 + 30}, ImColor(255,0,0),{40});
        std::string str1;                  
        str1 += std::to_string((int)PlayerCount);                   
        auto textSize = ImGui::CalcTextSize(str1.c_str(), 0, 25);
   //     float aa = Health*3.6;
        draw->AddText(NULL,30,{px + 3 - (textSize.x / 2), 85}, ImColor(255,255,255), str1.c_str());                            
    }
}




bool drawimguitick = false;


void GetTouch()
{
	for(;;)
	{
		usleep(2000);	
		ImGuiIO& ioooi = ImGui::GetIO();
		if (DrawIo[21] && ioooi.MouseDown[0] && point2.x <= NumIo[6] + NumIo[7] && point2.y <= py*2 - NumIo[5] + NumIo[7] && point2.x >= NumIo[6] - NumIo[7] && point2.y >= py*2 - NumIo[5] - NumIo[7])
		{			
			usleep(55000);		
			if (ioooi.MouseDown[0] && point2.x <= NumIo[6] + NumIo[7] && point2.y <= py*2 - NumIo[5] + NumIo[7] && point2.x >= NumIo[6] - NumIo[7] && point2.y >= py*2 - NumIo[5] - NumIo[7])
			{
				while (ioooi.MouseDown[0])
				{
					NumIo[6] = point2.x;
					NumIo[5] = py*2 - point2.y;
					usleep(500);		
				}
			}		
		}
	}
}

void tick()
{
        ImGuiIO& io = ImGui::GetIO();
        if (display == EGL_NO_DISPLAY)
        return;
        static ImVec4 clear_color = ImVec4(0, 0, 0, 0);
        ImGui_ImplOpenGL3_NewFrame();
		ImGuiStyle &Style = ImGui::GetStyle();
		auto Color = Style.Colors;
		static int Color_ = 0;
	    
        ImGui_ImplAndroid_NewFrame(init_screen_x, init_screen_y);
        ImGui::NewFrame();
   Style.Colors[ImGuiCol_Text]                   = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    Style.Colors[ImGuiCol_TextDisabled]           = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
    Style.Colors[ImGuiCol_WindowBg]               = ImVec4(0.94f, 0.94f, 0.94f, 1.00f);
    Style.Colors[ImGuiCol_ChildBg]                = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    Style.Colors[ImGuiCol_PopupBg]                = ImVec4(1.00f, 1.00f, 1.00f, 0.98f);
    Style.Colors[ImGuiCol_Border]                 = ImVec4(0.00f, 0.00f, 0.00f, 0.30f);
    Style.Colors[ImGuiCol_BorderShadow]           = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    Style.Colors[ImGuiCol_FrameBg]                = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    Style.Colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.26f, 0.59f, 0.98f, 0.40f);
    Style.Colors[ImGuiCol_FrameBgActive]          = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
    Style.Colors[ImGuiCol_TitleBg]                = ImVec4(0.96f, 0.96f, 0.96f, 1.00f);
    Style.Colors[ImGuiCol_TitleBgActive]          = ImVec4(0.82f, 0.82f, 0.82f, 1.00f);
    Style.Colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(1.00f, 1.00f, 1.00f, 0.51f);
    Style.Colors[ImGuiCol_MenuBarBg]              = ImVec4(0.86f, 0.86f, 0.86f, 1.00f);
    Style.Colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.98f, 0.98f, 0.98f, 0.53f);
    Style.Colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.69f, 0.69f, 0.69f, 0.80f);
    Style.Colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.49f, 0.49f, 0.49f, 0.80f);
    Style.Colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.49f, 0.49f, 0.49f, 1.00f);
    Style.Colors[ImGuiCol_CheckMark]              = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    Style.Colors[ImGuiCol_SliderGrab]             = ImVec4(0.26f, 0.59f, 0.98f, 0.78f);
    Style.Colors[ImGuiCol_SliderGrabActive]       = ImVec4(0.46f, 0.54f, 0.80f, 0.60f);
    Style.Colors[ImGuiCol_Button]                 = ImVec4(0.26f, 0.59f, 0.98f, 0.40f);
    Style.Colors[ImGuiCol_ButtonHovered]          = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    Style.Colors[ImGuiCol_ButtonActive]           = ImVec4(0.06f, 0.53f, 0.98f, 1.00f);
    Style.Colors[ImGuiCol_Header]                 = ImVec4(0.26f, 0.59f, 0.98f, 0.31f);
    Style.Colors[ImGuiCol_HeaderHovered]          = ImVec4(0.26f, 0.59f, 0.98f, 0.80f);
    Style.Colors[ImGuiCol_HeaderActive]           = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    Style.Colors[ImGuiCol_Separator]              = ImVec4(0.39f, 0.39f, 0.39f, 0.62f);
    Style.Colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.14f, 0.44f, 0.80f, 0.78f);
    Style.Colors[ImGuiCol_SeparatorActive]        = ImVec4(0.14f, 0.44f, 0.80f, 1.00f);
    Style.Colors[ImGuiCol_ResizeGrip]             = ImVec4(0.35f, 0.35f, 0.35f, 0.17f);
    Style.Colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
    Style.Colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
   // Style.Colors[ImGuiCol_Tab]                    = ImLerp(Style.Colors[ImGuiCol_Header],       Style.Colors[ImGuiCol_TitleBgActive], 0.90f);
    Style.Colors[ImGuiCol_TabHovered]             = Style.Colors[ImGuiCol_HeaderHovered];
   // Style.Colors[ImGuiCol_TabActive]              = ImLerp(Style.Colors[ImGuiCol_HeaderActive], Style.Colors[ImGuiCol_TitleBgActive], 0.60f);
   // Style.Colors[ImGuiCol_TabUnfocused]           = ImLerp(Style.Colors[ImGuiCol_Tab],          Style.Colors[ImGuiCol_TitleBg], 0.80f);
   // Style.Colors[ImGuiCol_TabUnfocusedActive]     = ImLerp(Style.Colors[ImGuiCol_TabActive],    Style.Colors[ImGuiCol_TitleBg], 0.40f);
    Style.Colors[ImGuiCol_PlotLines]              = ImVec4(0.39f, 0.39f, 0.39f, 1.00f);
    Style.Colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
    Style.Colors[ImGuiCol_PlotHistogram]          = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    Style.Colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.00f, 0.45f, 0.00f, 1.00f);
    Style.Colors[ImGuiCol_TableHeaderBg]          = ImVec4(0.78f, 0.87f, 0.98f, 1.00f);
    Style.Colors[ImGuiCol_TableBorderStrong]      = ImVec4(0.57f, 0.57f, 0.64f, 1.00f);   // Prefer using Alpha=1.0 here
    Style.Colors[ImGuiCol_TableBorderLight]       = ImVec4(0.68f, 0.68f, 0.74f, 1.00f);   // Prefer using Alpha=1.0 here
    Style.Colors[ImGuiCol_TableRowBg]             = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    Style.Colors[ImGuiCol_TableRowBgAlt]          = ImVec4(0.30f, 0.30f, 0.30f, 0.09f);
    Style.Colors[ImGuiCol_TextSelectedBg]         = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
    Style.Colors[ImGuiCol_DragDropTarget]         = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
    Style.Colors[ImGuiCol_NavHighlight]           = Style.Colors[ImGuiCol_HeaderHovered];
    Style.Colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(0.70f, 0.70f, 0.70f, 0.70f);
    Style.Colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.20f, 0.20f, 0.20f, 0.20f);
    Style.Colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.20f, 0.20f, 0.20f, 0.35f);



        Style.Colors[ImGuiCol_Header]                = ImColor(0, 0, 0, 0);
        Style.Colors[ImGuiCol_HeaderActive]          = ImColor(0, 0, 0, 0);
        Style.Colors[ImGuiCol_HeaderHovered]         = ImColor(46, 46, 46, 255);
		Style.WindowMinSize = ImVec2(700, 600);
		Style.WindowTitleAlign = ImVec2(0.5, 0.5);
		Style.WindowRounding = 5.5f;
		
		ImGui::Begin("PUBGM 64Bit 触摸自瞄"); 
		if (ImGui::BeginTabBar("Tab", ImGuiTabBarFlags_FittingPolicyScroll))
{
ImGui::StyleColorsLight();
if (ImGui::BeginTabItem("绘制")) {
        
            if (ImGui::Button("一键全开",{-1,75})) {   
                DrawIo[1] = true;
				DrawIo[2] = true;
                DrawIo[3] = true;
                DrawIo[4]= true;
                DrawIo[6]= true;
                DrawIo[8]= true;
                }
        ImGui::Checkbox("绘制方框", &DrawIo[1]);
	    ImGui::SameLine();
        ImGui::Checkbox("绘制距离", &DrawIo[8]);
		ImGui::SameLine();
        ImGui::Checkbox("绘制射线", &DrawIo[2]);
        ImGui::Checkbox("绘制骨骼", &DrawIo[3]);
		ImGui::SameLine();
        ImGui::Checkbox("绘制信息", &DrawIo[4]);
        ImGui::SameLine();
        ImGui::Checkbox("绘制血量", &DrawIo[6]);  
		ImGui::EndTabItem();		
		ImGui::Text("·不要使用小窗/分屏打开本辅助否则导致触摸无效\n·竖屏mt打开辅助后再返回游戏");
		ImGui::Text("群聊:691683935");
		ImGui::Text("自身地址:%p",MySelf);	
		ImGui::Text("数量:%d",Count);
}	
		
		
		
    if (ImGui::BeginTabItem("自瞄")) {
		ImGui::SwitchButton("开启自瞄", &DrawIo[20]);
		ImGui::Checkbox("触摸位置", &DrawIo[21]);
		ImGui::RadioButton("开火自瞄", &NumIo[0], 0.0f);      
        ImGui::SameLine();
        ImGui::RadioButton("开镜自瞄", &NumIo[0], 1.0f);    	
        ImGui::SameLine();
        ImGui::RadioButton("开镜/开火", &NumIo[0], 2.0f);    	
        ImGui::RadioButton("右边插头", &NumIo[10], 0.0f);      
        ImGui::SameLine();
        ImGui::RadioButton("左边插头", &NumIo[10], 1.0f);
        if(ImGui::CollapsingHeader("参数设置")){	
	    ImGui::SliderFloat("自瞄范围", &NumIo[3],10.0f,500.0f,"%.0f",1);     
		ImGui::SliderFloat("自瞄速度", &NumIo[4],0.1f,50.0f,"%.2f",2);
        ImGui::SliderFloat("压枪力度", &NumIo[9],0.1f,50.0f,"%.1f",3);        
        ImGui::SliderFloat("子弹速度", &NumIo[11],500.0f,1200.0f,"%.0f",3);                
	}	
		if (ImGui::Combo("自瞄部位", &style_idx2, "智能\0头部\0胸部\0臀部\0")) {
           switch (style_idx2) 
           {
             case 0:NumIo[8]=0.0; 
             break;
             case 1:NumIo[8]=1.0; 
             break;
             case 2:NumIo[8]=2.0; 
             break;
             case 3:NumIo[8]=3.0;
             break;	
           }          
        }
	}
ImGui::EndTabItem();
}
		
		if (ImGui::BeginTabItem("设置")) {
			ImGui::SliderFloat("帧数调试", &NumIo[12], 60, 144);
ImGui::Text("当前帧率%.1f FPS", ImGui::GetIO().Framerate);
    

          if(ImGui::Button("退出",ImVec2(100,55)))
            {
                exit(0);
            }
}
    
	
   	DrawPlayer(ImGui::GetForegroundDrawList()); 	
    ImGui::Render();  
   FPS = NumIo[12];
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    glClearColor(clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(display, surface);
}

void shutdown()
{
    if (!g_Initialized) {
        return;
    }
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    if (display != EGL_NO_DISPLAY){
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT){
            eglDestroyContext(display, context);
        }
        if (surface != EGL_NO_SURFACE){
            eglDestroySurface(display, surface);
        }
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;
    ANativeWindow_release(native_window);
}
