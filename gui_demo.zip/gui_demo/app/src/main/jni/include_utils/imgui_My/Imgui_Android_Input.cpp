#include "Imgui_Android_Input.h"
#include "imgui_log.h"
using namespace std;


bool IsChineseCharacter(const unsigned char* utf8Char) {
    // 获取第一个字节
    unsigned char byte1 = static_cast<unsigned char>(utf8Char[0]);
    // 判断是否是ASCII字符（单字节字符）
    if (byte1 <= 0x7F) {
        // ASCII字符不是中文字符
        return false;
    }

    // 判断是否是多字节字符的起始字节
    if ((byte1 & 0xC0) == 0xC0)
    {
        // 获取字符的字节数
        int numBytes = 0;
        while ((byte1 & (0x80 >> numBytes)) != 0)
        {
            numBytes++;
        }

        // 中文字符通常占用3个字节
        if (numBytes == 3)
        {
            // 进一步检查后续字节是否合法
            for (int i = 1; i < 3; i++)
            {
                unsigned char byte = static_cast<unsigned char>(utf8Char[i]);
                if ((byte & 0xC0) != 0x80)
                {
                    // 如果后续字节不是0x10xxxxxx形式，则不是中文字符
                    return false;
                }
            }
            return true;
        }
    }
    // 不是中文字符
    return false;
}

void ImguiAndroidInput::Copy(ImGuiInputTextCallbackData *CallbackData) {
    Copybuf = (char *) malloc(CallbackData->SelectionEnd - CallbackData->SelectionStart + 2);
    bzero(Copybuf, CallbackData->SelectionEnd - CallbackData->SelectionStart + 2);
    strlcat(Copybuf, &CallbackData->Buf[CallbackData->SelectionStart], CallbackData->SelectionEnd - CallbackData->SelectionStart + 1);
}

string ImguiAndroidInput::JNI_Copy() {
    if (!io->WantTextInput) {
        return "";
    }
    std::unique_lock<std::mutex> ulo(Copylk);
    ImguiAndroidInput::ActiveInputsw = 0;
    cond.wait(ulo, [this] { return ImguiAndroidInput::ActiveInputsw == 10; });
    string tmp = Copybuf;
    if (Copybuf != nullptr) {
        free(Copybuf);
        Copybuf = nullptr;
    }
    return tmp;
}

void ImguiAndroidInput::Paste(ImGuiInputTextCallbackData *CallbackData) {
    if (CallbackData->HasSelection()) {
        CallbackData->DeleteChars(CallbackData->SelectionStart, CallbackData->SelectionEnd - CallbackData->SelectionStart);
    }
    CallbackData->InsertChars(CallbackData->CursorPos, Pastebuf);
}

void ImguiAndroidInput::JNI_Paste(string data) {
    if (!io->WantTextInput) {
        return;
    }
    std::unique_lock<std::mutex> ulo(Pastelk);
    Pastebuf = data.c_str();
    this->ActiveInputsw = 1;
    cond.wait(ulo, [this] { return this->ActiveInputsw == 11; });
}

void ImguiAndroidInput::SelectAll(ImGuiInputTextCallbackData *CallbackData) {
    CallbackData->SelectAll();
    SelectSize = CallbackData->SelectionEnd - CallbackData->SelectionStart;
}

int ImguiAndroidInput::JNI_SelectAll() {
    ImguiAndroidInput::SelectSize = 0;
    if (!io->WantTextInput) {
        return SelectSize;
    }
    std::unique_lock<std::mutex> ulo(Selectlk);
    ImguiAndroidInput::ActiveInputsw = 2;
    cond.wait(ulo, [this] { return this->ActiveInputsw == 12; });
    return this->SelectSize;
}

void ImguiAndroidInput::Cut(ImGuiInputTextCallbackData *CallbackData) {
    Copybuf = (char *) malloc(CallbackData->SelectionEnd - CallbackData->SelectionStart + 2);
    bzero(Copybuf, CallbackData->SelectionEnd - CallbackData->SelectionStart + 2);
    strlcat(Copybuf, &CallbackData->Buf[CallbackData->SelectionStart], CallbackData->SelectionEnd - CallbackData->SelectionStart + 1);
    CallbackData->DeleteChars(CallbackData->SelectionStart, CallbackData->SelectionEnd - CallbackData->SelectionStart);
}

string ImguiAndroidInput::JNI_Cut() {
    if (!io->WantTextInput) {
        return "";
    }
    std::unique_lock<std::mutex> ulo(Cutlk);
    this->ActiveInputsw = 3;
    cond.wait(ulo, [this] { return this->ActiveInputsw == 13; });
    string tmp = Copybuf;
    if (Copybuf != nullptr) {
        free(Copybuf);
        Copybuf = nullptr;
    }
    return tmp;
}

int ImguiAndroidInput::inputCallback(ImGuiInputTextCallbackData *CallbackData) {
    switch (ActiveInputsw) {
        case 0: {
            Copy(CallbackData);
            ActiveInputsw = 10;
            cond.notify_all();
//			LOGE("inputCallback.Copy完成");
        }
            break;
        case 1: {
            Paste(CallbackData);
            ActiveInputsw = 11;
            cond.notify_all();
//			LOGE("inputCallback.Paste完成");
        }
            break;
        case 2: {
            SelectAll(CallbackData);
            ActiveInputsw = 12;
            cond.notify_all();
//			LOGE("inputCallback.SelectAll完成");
        }
            break;
        case 3: {
            Cut(CallbackData);
            ActiveInputsw = 13;
            cond.notify_all();
//			LOGE("inputCallback.Cut完成");
        }
            break;
        default: {

        }
            break;
    }

    if (ImGui::GetIO().KeysDown[67] == true && ImGui::GetIO().KeyMap[67] > 0) {
	    LOGE("触发删除 %d, %d, 光标位置%d", CallbackData->SelectionStart, CallbackData->SelectionEnd, CallbackData->CursorPos);
        if (CallbackData->SelectionStart != CallbackData->SelectionEnd) { //选中状态
            int minPos = std::min(CallbackData->SelectionStart, CallbackData->SelectionEnd);
            int maxPos = std::max(CallbackData->SelectionStart, CallbackData->SelectionEnd);
            int len = strlen(CallbackData->Buf);
            if (minPos >= 0 && maxPos <= len) {
			    //LOGE("minPos:%d, maxPos:%d", minPos, maxPos);
                CallbackData->DeleteChars(minPos, (maxPos - minPos));
                CallbackData->CursorPos = minPos;
            }        
        } else if (CallbackData->CursorPos >= 1) {   
            int bytesToDelete = 1; // 要删除的字节数
            // 判断当前位置的字节是否是UTF-8多字节字符的一部分
            while ((CallbackData->Buf[CallbackData->CursorPos - bytesToDelete] & 0xC0) == 0x80) {
                  bytesToDelete++;
            }
            CallbackData->DeleteChars((CallbackData->CursorPos - bytesToDelete), bytesToDelete);
        /*
            if (CallbackData->CursorPos >= 3) {
                unsigned char byte[3] = {
                    *(CallbackData->Buf + CallbackData->CursorPos-3),
                    *(CallbackData->Buf + CallbackData->CursorPos-2),
                    *(CallbackData->Buf + CallbackData->CursorPos-1)
                };  
    	        //LOGE("中文 : %s", &byte);
                if (IsChineseCharacter((const unsigned char *)&byte)) {
                    CallbackData->DeleteChars((CallbackData->CursorPos - 3), 3);
                } else {
                    CallbackData->DeleteChars((CallbackData->CursorPos - 1), 1);//光标位置 // 删除最后一个字符                     
                }
            } else {
                CallbackData->DeleteChars((CallbackData->CursorPos - 1), 1);//光标位置 // 删除最后一个字符                                 
            }
            */
        }
        ImGui::GetIO().KeyMap[67]--;
        return 1; // 返回1表示事件已经被处理
    }

	//LOGE("CallbackData->EventChar=%hu",CallbackData->EventChar);
    return 0;
}



void ImguiAndroidInput::addUTF8(const char *in_data) {

    io->AddInputCharactersUTF8(in_data);
//	LOGE("输入=%s,io=%d",in_data,io->WantTextInput);
//	LOGE("输入了字符串=%d",io->InputQueueCharacters.Size);
}

void ImguiAndroidInput::initImguiIo(ImGuiIO *io) {
    this->io = io;
    moveio   = false;
    f        = 1.0f;
    Copybuf  = nullptr;
    Pastebuf = nullptr;
    Inputio  = false;
    fps      = 60;
    if (max_fps == 0) {
        max_fps = 60;
    }
}

void ImguiAndroidInput::InputKey(int action, int code) {
    switch (action) {
        case InputAction::Action_DOWN : {
            if (code == 59) {
                io->KeyShift = true;
            }
            io->KeysDown[code] = true;
            io->KeyMap[code]++;
            break;
        }
        case InputAction::Action_UP : {
            if (code == 59) {
                io->KeyShift = false;
            }
            if (io->KeyMap[code] == 0) {
                io->KeysDown[code] = false;
            }
            break;
        }
    }
//	LOGE("action = %d  code = %d",action,code);
    usleep(10000);
}

 ClassInfo ImguiAndroidInput::gClassInfo = {nullptr,nullptr,nullptr,nullptr,nullptr,
                                                  nullptr,nullptr,nullptr,nullptr,nullptr};
void ImguiAndroidInput::toast(string &str) const {
    if (gClassInfo.jvm == nullptr || gClassInfo.pJclass == nullptr || gClassInfo.show == nullptr) {
        return;
    }
    JNIEnv  *env         = nullptr;
    bool    shouldDetach = false;
    if (gClassInfo.jvm->GetEnv((void **) &env, JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (gClassInfo.jvm->AttachCurrentThread(&env, nullptr) >= 0) {
            shouldDetach = true;
        }
    }
    jstring tmp          = env->NewStringUTF(str.c_str());
    env->CallStaticVoidMethod(gClassInfo.pJclass, gClassInfo.show, tmp);
    env->DeleteLocalRef(tmp);
    if (shouldDetach) {
        gClassInfo.jvm->DetachCurrentThread();
    }
}

bool ImguiAndroidInput::openInput(){
    if (gClassInfo.jvm == nullptr || gClassInfo.pJclass == nullptr || gClassInfo.openInput == nullptr) {
        return false;
    }
    JNIEnv  *env         = nullptr;
    bool    shouldDetach = false;
    if (gClassInfo.jvm->GetEnv((void **) &env, JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (gClassInfo.jvm->AttachCurrentThread(&env, nullptr) >= 0) {
            shouldDetach = true;
        }
    }

    jboolean tmp =  env->CallStaticBooleanMethod(gClassInfo.pJclass,gClassInfo.openInput);
    if (shouldDetach) {
        gClassInfo.jvm->DetachCurrentThread();
    }
    return tmp;
}

bool ImguiAndroidInput::closeInput(){
    if (gClassInfo.jvm == nullptr || gClassInfo.pJclass == nullptr || gClassInfo.closeInput == nullptr) {
        return false;
    }
    JNIEnv  *env         = nullptr;
    bool    shouldDetach = false;
    if (gClassInfo.jvm->GetEnv((void **) &env, JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (gClassInfo.jvm->AttachCurrentThread(&env, nullptr) >= 0) {
            shouldDetach = true;
        }
    }
    jboolean tmp =  env->CallStaticBooleanMethod(gClassInfo.pJclass,gClassInfo.closeInput);
    if (shouldDetach) {
        gClassInfo.jvm->DetachCurrentThread();
    }
    return tmp;
}

void ImguiAndroidInput::ioset(jint pos, jint v) const {
    if (gClassInfo.jvm == nullptr || gClassInfo.pJclass == nullptr || gClassInfo.io == nullptr) {
        return;
    }
//	LOGE("开始ioset");
    JNIEnv  *env         = nullptr;
    bool    shouldDetach = false;
    if (gClassInfo.jvm->GetEnv((void **) &env, JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (gClassInfo.jvm->AttachCurrentThread(&env, nullptr) >= 0) {
            shouldDetach = true;
        }
    }
    jstring tmp          = env->NewStringUTF("psio");
//	LOGE("set.pos=%d,v=%d", pos, v);
    env->CallStaticVoidMethod(gClassInfo.pJclass, gClassInfo.io, tmp, pos, v);
//	env->CallVoidMethod(gClassInfo.obj,gClassInfo.v,tmp,pos,v);
//	LOGE("准备释放jstring");
    env->DeleteLocalRef(tmp);
    if (shouldDetach) {
//		LOGE("准备释放jvm线程");
        gClassInfo.jvm->DetachCurrentThread();
    }
}

void ImguiAndroidInput::isLongTouch(int x, int y) {
    if (gClassInfo.jvm == nullptr || gClassInfo.pJclass == nullptr || gClassInfo.isLongTouch == nullptr) {
        return;
    }
    JNIEnv  *env         = nullptr;
    bool    shouldDetach = false;
    if (gClassInfo.jvm->GetEnv((void **) &env, JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (gClassInfo.jvm->AttachCurrentThread(&env, nullptr) >= 0) {
            shouldDetach = true;
        }
    }
    env->CallStaticVoidMethod(gClassInfo.pJclass,gClassInfo.isLongTouch,x,y);
    if (shouldDetach) {
//		LOGE("准备释放jvm线程");
        gClassInfo.jvm->DetachCurrentThread();
    }
}



void ImguiAndroidInput::funMshowinit(jclass thiz, JNIEnv *env) {

    (*env).GetJavaVM(&gClassInfo.jvm);
    gClassInfo.pJclass = thiz;
//		gClassInfo.pJclass = env->GetObjectClass(thiz);
    gClassInfo.show    = env->GetStaticMethodID(gClassInfo.pJclass, "mShow", "(Ljava/lang/String;)V");
    if (nullptr == gClassInfo.show) {
			LOGE("can't find method mShow from JniClass");
        return;
    } else {
			LOGE("find method mShow from JniClass");
    }
    gClassInfo.io = env->GetStaticMethodID(gClassInfo.pJclass, "mIO", "(Ljava/lang/String;II)V");
    if (nullptr == gClassInfo.io) {
			LOGE("can't find method mIO from JniClass");
        return;
    } else {
			LOGE("find method mIO from JniClass");
    }
    gClassInfo.openInput = env->GetStaticMethodID(gClassInfo.pJclass,"openInput","()Z");
    if (nullptr == gClassInfo.openInput) {
			LOGE("can't find method openInput from JniClass");
        return;
    } else {
			LOGE("find method openInput from JniClass");
    }
    gClassInfo.closeInput = env->GetStaticMethodID(gClassInfo.pJclass,"closeInput","()Z");
    if (nullptr == gClassInfo.closeInput) {
			LOGE("can't find method closeInput from JniClass");
        return;
    } else {
			LOGE("find method closeInput from JniClass");
    }
    gClassInfo.isLongTouch = env->GetStaticMethodID(gClassInfo.pJclass,"isLongTouch","(II)V");
    if (nullptr == gClassInfo.isLongTouch) {
			LOGE("can't find method isLongTouch from JniClass");
        return;
    } else {
			LOGE("find method isLongTouch from JniClass");
    }
    gClassInfo.obj = (*env).NewGlobalRef(thiz);
    if (nullptr == gClassInfo.obj) {
			LOGE("can't find jobject");
        return;
    } else {
			LOGE("find jobject");
    }
}


void ImguiAndroidInput::longTouchLoop(){
    /*
    if (loopRun){
        return;
    }
    thread loop([this]{
        for (;;){
            if ( TOUCH_TIMER.islooptimestart ){
                if (TOUCH_TIMER.getlooptime()>150000000&&!this->isMouseMove&&io->WantTextInput){
                    LOGE("长按了编辑框");
                    ioset(3,0);
//                    isLongTouch((int)DOWN_x,(int)DOWN_y);
                    loopRun = false;
                    return ;
                }
                if (this->isMouseMove || !io->WantTextInput || !io->MouseDown[0] || !loopRun){
                    loopRun = false;
                    return;
                }
            }
            usleep(1000);
        }
    });
    loop.detach();
    */
}


void ImguiAndroidInput::InputTouchEvent(int event_get_action, float x, float y) {
	LOGE("event.key=%d",event_get_action);
    if (io->WantCaptureMouse) {
		LOGE("imgui获得焦点");
    } else {
		LOGE("imgui无焦点");
    }
    if (io->WantTextInput) {
		LOGE("imgui输入获得焦点");
        if (!Inputio && event_get_action != eTouchEvent::TOUCH_OUTSIDE) {
//            ioset(2, 1);
            Inputio = openInput();
//            Inputio = io->WantTextInput;
			LOGE("imgui呼出输入法%d",Inputio);
        }
    } else {
		LOGE("imgui输入丢失焦点");
        if (Inputio) {
//            ioset(2, 0);
            Inputio = closeInput();
			LOGE("imgui关闭输入法%d",Inputio);
        }
    }
    if (ItemHovered) {
        Activeio = ItemHovered;
    }

    switch (event_get_action) {
        case eTouchEvent::TOUCH_OUTSIDE: io->MouseDown[0] = false;
            moveio   = false;
            Activeio = false;
            Scrollio = false;
            loopRun = false;
            DOWN_x   = DOWN_y   = 0;
            if (Inputio) {
//                ioset(2, 0);
                Inputio = closeInput();
			LOGE("imgui关闭输入法%d",Inputio);
            }
            break;
        case eTouchEvent::TOUCH_DOWN: DOWN_x = x;
            DOWN_y = y;
            io->MousePos.x = x;
            io->MousePos.y = y;
            io->MouseDown[0] = true;
            Activeio   = ItemHovered;
            SetScrollX = 0.0f;
            SetScrollY = 0.0f;
            ScrollXMAX = 0.0f;
            ScrollYMAX = 0.0f;
            TOUCH_TIME = 0.0f;
            upio       = false;
            Scrollio   = false;
            runScroll  = false;
            this->isMouseMove = false;
            TOUCH_TIMER.start();
            TOUCH_TIMER.looptimestart();
            longTouchLoop();
            loopRun = true;
            if (y <= g_window->TitleBarHeight() && !moveio) {
                moveio = true;
            }
            break;
        case eTouchEvent::TOUCH_UP:
            io->MouseDown[0] = false;
            SetScrollX = x - DOWN_x;
            SetScrollY = y - DOWN_y;
            moveio     = false;
            Activeio   = false;
            runScroll  = false;
            loopRun = false;
            DOWN_x     = DOWN_y = 0;
            TOUCH_TIME = TOUCH_TIMER.stop(1);
            break;
        case eTouchEvent::TOUCH_MOVE:
            io->MousePos.x = x;
            io->MousePos.y                          = y;
            loopRun = false;
            if (y > g_window->TitleBarHeight() && abs(DOWN_x - x) > 3.0f  ||  abs(DOWN_y - y) > 3.0f ){
                this->isMouseMove = true;
                Scrollio = true;
            }

			LOGE("滑动");
            break;
        default: break;
    }
//	LOGE("IsItemActive=%d",ItemActive);
//	LOGE("IsItemHovered=%d",ItemHovered);
//	LOGE("IsItemFocused=%d",ItemFocused);
//	LOGE("IsItemEdited=%d",ItemEdited);
//	LOGE("界面TOUCH.x=%f .y=%f",x,y);
	LOGE("输入法io%d",Inputio);
}

float ImguiAndroidInput::funScroll() {
    nowScrollX = ImGui::GetScrollX();
    nowScrollY = ImGui::GetScrollY();
    runScroll  = true;
    if (io->MouseDown[0]) {
        if (nowScrollX > 0.0f || nowScrollX < ImGui::GetScrollMaxX()) {
            ImGui::SetScrollX(ImGui::GetScrollX() - io->MouseDelta.x);
        }
//        ImGui::SetScrollX(ImGui::GetScrollX() - io->MouseDelta.x);
//        ImGui::SetScrollY(ImGui::GetScrollY() - io->MouseDelta.y);
        if (nowScrollY > 0.0f || nowScrollY < ImGui::GetScrollMaxY()) {
            ImGui::SetScrollY(ImGui::GetScrollY() - io->MouseDelta.y);
        }
//		TOUCH_TIME = io->MouseDownDuration[0];
        upio = false;
    } else {
        if (!upio) {
            if (TOUCH_TIME > 300) {
                SetScrollX = 0;
                SetScrollY = 0;
                Scrollio   = false;
                runScroll  = false;
            }
            Seed_up    = abs(SetScrollX) / (TOUCH_TIME);
//			LOGE("SetScrollX=%f",SetScrollX);
            ScrollX    = SetScrollX / (TOUCH_TIME / 1000 * (float) fps);
            SetScrollX *= Seed_up * f;
            ScrollXMAX = SetScrollX;
//			LOGE("SetScrollX=%f,Seed_up=%f,time%f",SetScrollX,Seed_up,TOUCH_TIME);
            Seed_up    = abs(SetScrollY) / (TOUCH_TIME);
//			LOGE("SetScrollX=%f",SetScrollY);
            ScrollY    = SetScrollY / (TOUCH_TIME / 1000 * (float) fps);
            SetScrollY *= Seed_up * f;
            ScrollYMAX = SetScrollY;
//			LOGE("SetScrollY=%f,Seed_up=%f,time%f",SetScrollY,Seed_up,TOUCH_TIME);
            upio       = true;
        }
        ScrollXRatio = (SetScrollX / ScrollXMAX);
        ScrollYRatio = (SetScrollY / ScrollYMAX);
        if (nowScrollX > 0.0f && nowScrollX < ImGui::GetScrollMaxX()) {
            ImGui::SetScrollX(nowScrollX - ScrollX * ScrollXRatio);
        } else {
            ScrollX = 0.0f;
        }
        if (nowScrollY > 0.0f && nowScrollY < ImGui::GetScrollMaxY()) {
            ImGui::SetScrollY(nowScrollY - ScrollY * ScrollYRatio);
        } else {
            ScrollY = 0.0f;
        }
        SetScrollX -= (ScrollX * ScrollXRatio);
        SetScrollY -= (ScrollY * ScrollYRatio);
        if (ScrollX * ScrollXRatio >= -0.9f && ScrollX * ScrollXRatio <= 0.9f && ScrollY * ScrollYRatio >= -0.9f && ScrollY * ScrollYRatio <= 0.9f) {
            SetScrollX = 0;
            SetScrollY = 0;
            Scrollio   = false;
            runScroll  = false;
        }
//						LOGE("当前Window.ScrollXRatio=%f,.ScrollYRatio=%f,SetScroll.x%f,SetScroll.y%f,ScrollX=%f,ScrollY%f",ScrollXRatio,ScrollYRatio,SetScrollX,SetScrollY,ScrollX,ScrollY);
    }
    return nowScrollX;
}

void ImguiAndroidInput::setMaxFPS(int MAX_FPS) {
    this->max_fps = MAX_FPS;
//	LOGE("设置FPS=%d",MAX_FPS);
}


void ImguiAndroidInput::StartLockWheelingWindow(ImGuiWindow *window) {
    if (g->WheelingWindow == window) {
        return;
    }
    g->WheelingWindow              = window;
    g->WheelingWindowRefMousePos = g->IO.MousePos;
    g->WheelingWindowReleaseTimer  = 2.0f;
}


float ImguiAndroidInput::funScroll(ImGuiWindow *Window) {
    if (!Window) {
        return 0.0f;
    }
    StartLockWheelingWindow(Window);
    nowScrollX = Window->Scroll.x;
    nowScrollY = Window->Scroll.y;
    runScroll  = true;
    if (this->isMouseMove) {
        ImGui::SetScrollX(Window, Window->Scroll.x - io->MouseDelta.x);
        ImGui::SetScrollY(Window, Window->Scroll.y - io->MouseDelta.y);
//		TOUCH_TIME = io->MouseDownDuration[0];
        upio = false;
    } else {
        if (!upio) {
            if (TOUCH_TIME > 300) {
                SetScrollX = 0;
                SetScrollY = 0;
                Scrollio   = false;
                runScroll  = false;
            }
            Seed_up    = abs(SetScrollX) / (TOUCH_TIME);
//			LOGE("SetScrollX=%f",SetScrollX);
            ScrollX    = SetScrollX / (TOUCH_TIME / 1000 * (float) fps);
            SetScrollX *= Seed_up * f;
            ScrollXMAX = SetScrollX;
//			LOGE("SetScrollX=%f,Seed_up=%f,time%f",SetScrollX,Seed_up,TOUCH_TIME);
            Seed_up    = abs(SetScrollY) / (TOUCH_TIME);
//			LOGE("SetScrollX=%f",SetScrollY);
            ScrollY    = SetScrollY / (TOUCH_TIME / 1000 * (float) fps);
            SetScrollY *= Seed_up * f;
            ScrollYMAX = SetScrollY;
//			LOGE("SetScrollY=%f,Seed_up=%f,time%f",SetScrollY,Seed_up,TOUCH_TIME);
            upio       = true;
        }
        ScrollXRatio = (SetScrollX / ScrollXMAX);
        ScrollYRatio = (SetScrollY / ScrollYMAX);

        if (nowScrollX > 0.0f && nowScrollX < Window->ScrollMax.x) {
            ImGui::SetScrollX(Window, nowScrollX - ScrollX * ScrollXRatio);
        } else {
            ScrollX = 0.0f;
        }
        if (nowScrollY > 0.0f && nowScrollY < Window->ScrollMax.y) {
            ImGui::SetScrollY(Window, nowScrollY - ScrollY * ScrollYRatio);
        } else {
            ScrollY = 0.0f;
        }
        SetScrollX -= (ScrollX * ScrollXRatio);
        SetScrollY -= (ScrollY * ScrollYRatio);
        if (ScrollX * ScrollXRatio >= -0.9f && ScrollX * ScrollXRatio <= 0.9f && ScrollY * ScrollYRatio >= -0.9f && ScrollY * ScrollYRatio <= 0.9f) {
            SetScrollX = 0;
            SetScrollY = 0;
            Scrollio   = false;
            runScroll  = false;
        }
//						LOGE("当前Window.ScrollXRatio=%f,.ScrollYRatio=%f,SetScroll.x%f,SetScroll.y%f,ScrollX=%f,ScrollY%f",ScrollXRatio,ScrollYRatio,SetScrollX,SetScrollY,ScrollX,ScrollY);
    }
    return nowScrollX;
}

void ImguiAndroidInput::setImguiContext(ImGuiContext *g_) {
    this->g = g_;
}

void ImguiAndroidInput::setwin(ImGuiWindow *g_window_) {
    this->g_window = g_window_;
}

