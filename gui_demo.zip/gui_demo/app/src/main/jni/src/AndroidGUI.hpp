#ifndef MENU_ROODS_GUI_H
#define MENU_ROODS_GUI_H

#include <jni.h>
#include <string>           //C++ (字符串)
#include <thread>           // thread(C++多线程)
#include <unistd.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/native_window_jni.h>

#include <dirent.h>
#include <sys/types.h>

#include "jni_log.h"
#include "Font/imgui_icon.h"
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"
#include "imgui/backends/imgui_Input_android.h"
#include "imgui/backends/imgui_impl_android.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "imgui_My/Imgui_Android_Input.h"

class AndroidGUI {
private:
    bool login = false;
    int frontDesk_pid = -1;
    char frontDesk_packageName[256] = "???";
    //char titleChar[256]; //标题
    char clipboard[256] = {0}; //剪贴板
    bool g_Initialized;
    int           FPS ;
    float         current_fps;
    ImGuiStyle* style;
    std::thread *SurfaceThread = nullptr; //视野thread
    ANativeWindow *surface_window;  //视图
    MyInputEvent inputEvent;           //触摸
    
    int ListPage = 0;
    int _ScreenX = 0;
    int _ScreenY = 0;

    ImguiAndroidInput        *input;

    void init_start();
    int init_Egl();
    int init_Imgui();
    
    void clearBuffers();
    void imguiMainWinStart() ;
    void imguiMainWinEnd();
    int swapBuffers();
    void SetuptheGUIstyle(); //设置UI风格
    void LoginWindow();

    void Layoutofevent(); //布局事件
    void LayoutFloatingball(ImVec2 pos); //布局悬浮球
    
    void InitMenu(bool* isOpen);
    void Activi(float width, float height);
    int32_t handleInputEvent(MyInputEvent inputEvent);
    

public:
    ImVector<ImGuiWindow*>       WinList; //所有窗口
    struct MenuPos {
        float w;
        float h;
        float x;
        float y;
    } menuPos;
    
    void onSurfaceCreate(JNIEnv *env, jobject surface);
    void navateInputEvent(JNIEnv *env, jobject motionEvent);
    void GUIthread_start(int width, int height);
    void set_clipboard(const char *str);

    void set_input(ImguiAndroidInput *input_);                             //传递 触摸依赖 &
        
    AndroidGUI();   //类构造 函数
    
    ~AndroidGUI() {
    }    
    
};


#endif //MENU_ROODS_GUI_H
