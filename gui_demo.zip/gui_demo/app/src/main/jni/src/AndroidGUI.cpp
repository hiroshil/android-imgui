#include "AndroidGUI.hpp"
#include "Font/font_OPPO_ch.h"
#include "Font/font_awesome.h"


#include "include_/timer_tool.h"


EGLDisplay g_EglDisplay = EGL_NO_DISPLAY;
EGLSurface g_EglSurface = EGL_NO_SURFACE;
EGLContext g_EglContext = EGL_NO_CONTEXT;

const EGLint attribs1[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_BLUE_SIZE, 5,   //-->delete
        EGL_GREEN_SIZE, 6,  //-->delete
        EGL_RED_SIZE, 5,    //-->delete
        EGL_BUFFER_SIZE, 32,  //-->new field
        EGL_DEPTH_SIZE, 16,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
};

AndroidGUI::AndroidGUI() {
    this->FPS = 90;
}

int AndroidGUI::init_Egl() {
	g_EglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
	if (g_EglDisplay == EGL_NO_DISPLAY)
		LOGE("%s", "eglGetDisplay(EGL_DEFAULT_DISPLAY) returned EGL_NO_DISPLAY");

	if (eglInitialize(g_EglDisplay, 0, 0) != EGL_TRUE)
		LOGE("%s", "eglInitialize() returned with an error");

	// const EGLint egl_attributes[] = { EGL_BLUE_SIZE, 8, EGL_GREEN_SIZE, 8,
	// EGL_RED_SIZE, 8, EGL_DEPTH_SIZE, 16 ,EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_NONE };
	EGLint num_configs = 0;
	if (eglChooseConfig(g_EglDisplay, attribs1, nullptr, 0, &num_configs) != EGL_TRUE) {
		LOGE("%s", "eglChooseConfig() returned with an error");
	}
	
	if (num_configs == 0)
		LOGE("%s", "eglChooseConfig() returned 0 matching config");

	// Get the first matching config
	EGLConfig egl_config;
	eglChooseConfig(g_EglDisplay, attribs1, &egl_config, 1, &num_configs);
	
	EGLint egl_format;
	eglGetConfigAttrib(g_EglDisplay, egl_config, EGL_NATIVE_VISUAL_ID, &egl_format);
	ANativeWindow_setBuffersGeometry(this->surface_window, 0, 0, egl_format);

	const EGLint egl_context_attributes[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
	g_EglContext = eglCreateContext(g_EglDisplay, egl_config, EGL_NO_CONTEXT, egl_context_attributes);
	if (g_EglContext == EGL_NO_CONTEXT) {
		LOGE("%s", "eglCreateContext() returned EGL_NO_CONTEXT");
    }
    
	g_EglSurface = eglCreateWindowSurface(g_EglDisplay, egl_config, this->surface_window, NULL);
	eglMakeCurrent(g_EglDisplay, g_EglSurface, g_EglSurface, g_EglContext);
    return 1;
}

int AndroidGUI::init_Imgui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();		
    ImGui::StyleColorsClassic();
    ImGui_ImplAndroid_Init(this->surface_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
	static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 3.0;
    icons_config.OversampleV = 3.0;		
    ImFont *Font_ch = io.Fonts->AddFontFromMemoryTTF((void *)OPPO_ch_data, OPPO_ch_size, 32.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
	io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 32.0f, &icons_config, icons_ranges);
    io.Fonts->AddFontDefault();
    IM_ASSERT(Font_ch != NULL);
    ImGui::GetStyle().ScaleAllSizes(3.0f);
    glViewport(0, 0, this->_ScreenX, this->_ScreenY);
    return 1;
}


void AndroidGUI::clearBuffers() {
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);              // background color
}

void AndroidGUI::imguiMainWinStart() {
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
}

void AndroidGUI::imguiMainWinEnd() {
    ImGui::Render();
	glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

int AndroidGUI::swapBuffers() {
    //opengl当前buff传递至屏幕
    if (eglSwapBuffers(g_EglDisplay, g_EglSurface)) {
        return 1;
    } else {
        LOGE("eglSwapBuffers  error = %u", glGetError());
        return 0;
    }
}

void AndroidGUI::init_start() {
//    if (this->g_Initialized) return;
	this->init_Egl();
	this->init_Imgui();
    this->SetuptheGUIstyle(); //设置颜色
	
    
    this->g_Initialized = true;    

    this->input->initImguiIo(&ImGui::GetIO());           //Imgui_Android_Input
    this->input->setImguiContext(ImGui::GetCurrentContext());      //Imgui_Android_Input
    //this->input->setwin(this->surface_window); //Imgui_Android_Input

    timer_tool Auto_FPS;
    Auto_FPS.SetFps(this->FPS);
    Auto_FPS.AotuFPS_init();
	Auto_FPS.setAffinity();
	
    for (;;) {
        this->clearBuffers();        //清除0
        this->imguiMainWinStart(); //start     
                                
        this->Layoutofevent();      //UI
        
        this->imguiMainWinEnd(); //end_1
        this->swapBuffers();      //end_2
       
        this->WinList = ImGui::GetCurrentContext()->Windows; //获取窗口
        Auto_FPS.SetFps(this->FPS);
        this->current_fps = Auto_FPS.AotuFPS();
    }
}

void AndroidGUI::navateInputEvent(JNIEnv *env, jobject motionEvent) {
    if (this->g_Initialized) {
        static struct {
            jclass clazz;
            jmethodID getAction;
            jmethodID getRawX;
            jmethodID getRawY;
            jmethodID getToolType;
            jmethodID getButtonState;
            jmethodID getAxisValue;
        } jme = {};
        if (jme.clazz == nullptr) {
            jme.clazz = env->GetObjectClass(motionEvent);
            jme.getAction = env->GetMethodID(jme.clazz, "getAction", "()I");
            jme.getRawX = env->GetMethodID(jme.clazz, "getRawX", "()F");
            jme.getRawY = env->GetMethodID(jme.clazz, "getRawY", "()F");
            jme.getToolType = env->GetMethodID(jme.clazz, "getToolType", "(I)I");
            jme.getButtonState = env->GetMethodID(jme.clazz, "getButtonState", "()I");
            jme.getAxisValue = env->GetMethodID(jme.clazz, "getAxisValue", "(II)F");
        }
        this->inputEvent.Action = env->CallIntMethod(motionEvent, jme.getAction);
        this->inputEvent.x = env->CallFloatMethod(motionEvent, jme.getRawX);
        this->inputEvent.y = env->CallFloatMethod(motionEvent, jme.getRawY);
        int32_t event_pointer_index = (inputEvent.Action & 65280) >> 8;
        this->inputEvent.ToolType = env->CallIntMethod(motionEvent, jme.getToolType, event_pointer_index);
        this->inputEvent.ButtonState = env->CallIntMethod(motionEvent, jme.getButtonState);
        this->inputEvent.AXIS_VSCROLL = env->CallFloatMethod(motionEvent, jme.getAxisValue, 9, event_pointer_index);
        this->inputEvent.AXIS_HSCROLL = env->CallFloatMethod(motionEvent, jme.getAxisValue, 10, event_pointer_index);
        //this->handleInputEvent(this->inputEvent);        
        this->input->InputTouchEvent(this->inputEvent.Action, this->inputEvent.x, this->inputEvent.y);
    }
}

void AndroidGUI::set_clipboard(const char *str) {
    sprintf(this->clipboard, "%s", &(*str));   
}

void AndroidGUI::onSurfaceCreate(JNIEnv *env, jobject surface) {
    this->surface_window = ANativeWindow_fromSurface(env, surface);
	ANativeWindow_acquire(this->surface_window);    
}

int32_t AndroidGUI::handleInputEvent(MyInputEvent inputEvent_) {
    return ImGui_ImplAndroid_HandleInputEvent(inputEvent_);
}

void AndroidGUI::GUIthread_start(int width, int height) {
    glViewport(0, 0, width, height);
    //ImGui::GetIO().DisplaySize = ImVec2((float)width, (float)height);
    this->_ScreenX = (width > height) ? width : height;
    this->_ScreenY = (width < height) ? width : height;
    this->SurfaceThread = new std::thread([this] { init_start(); });
    this->SurfaceThread->detach();
}

// 依赖库 Imgui_Android_Input 传递
void AndroidGUI::set_input(ImguiAndroidInput *input_) {
    this->input = input_;
}

