#include <jni.h>
#include "src/AndroidGUI.hpp"
#include "imgui_My/Imgui_Android_Input.h"

AndroidGUI *MGui_jni = nullptr;  //自己 jni C++类
ImguiAndroidInput input;     //Imgui_Android_Input.h

//发送窗口大小
extern "C" {
JNIEXPORT jobjectArray JNICALL GetImguiwinsize(JNIEnv *env, jclass clazz, jclass call) {
    static float FLOAT[4] = {0};
    static struct {
        jclass Call_cls;
        jfieldID id;
        jfieldID name;
        jfieldID X;
        jfieldID Y;
        jfieldID X1;
        jfieldID Y1;
        jfieldID Act;
    } J_CallData = {};    
    if (J_CallData.Call_cls == nullptr) {
        J_CallData.Call_cls = call;//env->FindClass("gui/android/demo/CallData");
        J_CallData.id = env->GetFieldID(J_CallData.Call_cls, "ID", "I");
        J_CallData.name = env->GetFieldID(J_CallData.Call_cls, "WinName", "Ljava/lang/String;");
        J_CallData.X = env->GetFieldID(J_CallData.Call_cls, "X", "F");
        J_CallData.Y = env->GetFieldID(J_CallData.Call_cls, "Y", "F");
        J_CallData.X1 = env->GetFieldID(J_CallData.Call_cls, "X1", "F");
        J_CallData.Y1 = env->GetFieldID(J_CallData.Call_cls, "Y1", "F");
        J_CallData.Act = env->GetFieldID(J_CallData.Call_cls,"Action", "Z");
    }
    
    J_CallData.Call_cls = call;
    jobjectArray callarrayObj;
    if (MGui_jni != nullptr && MGui_jni->WinList.Size != 0 && J_CallData.Call_cls != nullptr) {
        callarrayObj = env->NewObjectArray(MGui_jni->WinList.Size, J_CallData.Call_cls, NULL);//创建对象列表
        //LOGE("窗口数据 W:%f H:%f",MGui_jni->g_window->Size.x,MGui_jni->g_window->Size.y);         
        int count = 0;
        for (ImGuiWindow *win:MGui_jni->WinList) {
            FLOAT[0] = win->Pos.x;
            FLOAT[1] = win->Pos.y;
            FLOAT[2] = win->Size.x;
            FLOAT[3] = win->Size.y;
            //LOGE("id:%d 窗口是否隐藏:%s", win->ID,win->Hidden? "是" : "否");
            //LOGE("id:%d 窗口是否隐藏1:%s", win->ID,win->Active? "是" : "否");
            //设置数据对象
            jobject daclass = env->AllocObject(J_CallData.Call_cls);             
            env->SetIntField(daclass, J_CallData.id, win->ID);
            env->SetObjectField(daclass, J_CallData.name, env->NewStringUTF(win->Name));
            env->SetFloatField(daclass, J_CallData.X, FLOAT[0]);
            env->SetFloatField(daclass, J_CallData.Y, FLOAT[1]);
            env->SetFloatField(daclass, J_CallData.X1, FLOAT[2]);
            env->SetFloatField(daclass, J_CallData.Y1, FLOAT[3]);
            env->SetBooleanField(daclass, J_CallData.Act, win->Active);

            env->SetObjectArrayElement(callarrayObj, count, daclass);
            env->DeleteLocalRef(daclass);
            count++;
        }
        return callarrayObj;             
    } else {
        return NULL;
    }
}
}

extern "C" {
    //初始化opengl窗口
    void setSurface(JNIEnv *env, jclass cla, jobject surface)__attribute__ ((__annotate__ (("fla")))) { 
        MGui_jni->onSurfaceCreate(env, surface);
        MGui_jni->set_input(&input);                             //传递 触摸依赖 &
    }
}

extern "C" {
    //开启绘制
    jstring start(JNIEnv *env, jclass clazz, jint width, jint height) {
      	MGui_jni->GUIthread_start(width, height);       
        return env->NewStringUTF("YES");
    }
}

extern "C" {
    //获取触摸事件
    void navateInputEvent(JNIEnv *env, jclass cl_obj, jobject motionEvent) {
        MGui_jni->navateInputEvent(env, motionEvent);
    }
}

extern "C" {
    jfloat getMenuX(JNIEnv *env, jclass clazz) {
        return MGui_jni->menuPos.x;
    }
    jfloat getMenuY(JNIEnv *env, jclass clazz) {
        return MGui_jni->menuPos.y;
    }
    jfloat getMenuW(JNIEnv *env, jclass clazz) {
        return MGui_jni->menuPos.w;
    }
    jfloat getMenuH(JNIEnv *env, jclass clazz) {
        return MGui_jni->menuPos.h;
    }
}

extern "C" {
    void setKey(JNIEnv *env, jclass clazz, jstring key) {
        char local_stringDatat_input[128];
        const char *key_C = env->GetStringUTFChars(key, NULL);
        if (strlen(key_C) >= sizeof(local_stringDatat_input)) {
            memmove((void *)&(local_stringDatat_input), (void *) key_C, 10);                                
            strcat(local_stringDatat_input, "...文件过长");//校验长度
        } else {
            memmove((void *)&(local_stringDatat_input), (void *) key_C, sizeof(local_stringDatat_input));                                
        }
        
        MGui_jni->set_clipboard(local_stringDatat_input);
        env->ReleaseStringUTFChars(key, key_C);
    }
}





void initEventClass(JNIEnv *env, jclass clazz, jobject _obj_) {
    jclass class_obj = env->GetObjectClass(_obj_);
    input.funMshowinit(class_obj, env);
}
void inputcharOnJNI(JNIEnv *env, jclass clazz, jstring msg) {
    const char *tmp1 = env->GetStringUTFChars(msg, NULL);
    input.addUTF8(tmp1);
    env->ReleaseStringUTFChars(msg, tmp1);
}
void sendKeyEvent_JNI(JNIEnv *env, jclass clazz, jint action, jint code) {
    input.InputKey(action, code);
}
void finishComposingText_JNI(JNIEnv *env, jclass clazz) {
    input.Inputio = false;
}

/*****************************************
*   native方法动态注册辅助函数
*****************************************/
#ifndef NELEM
    #define NELEM(x) ((int) (sizeof(x) / sizeof((x)[0])))
#endif
extern "C" {
    int jniRegisterNativeMethods(JNIEnv *env, const char *className, JNINativeMethod *gMethods, int numMethods) {
        jclass clazz = env->FindClass(className);
        if (clazz == NULL) {
            return JNI_FALSE;
        }
        if (env->RegisterNatives(clazz, gMethods, numMethods) < 0) {
            return JNI_FALSE;
        }
        return JNI_TRUE;
    }
}

extern "C" {
    int register_native_api(JNIEnv *env) {
        JNINativeMethod native_method_table[] = {
            {
                "start", "(II)Ljava/lang/String;",
         		(void *) start
    		},		
            {
                "setSurface", "(Landroid/view/Surface;)V", 
        		(void *) setSurface
            },
            {
                "navateInputEvent",  "(Landroid/view/MotionEvent;)V", 
                (void *) navateInputEvent
            },
            
            {
                "GetImguiwinsize",  "(Ljava/lang/Class;)[Lgui/android/demo/CallData;", 
                (void *) GetImguiwinsize
            },
            {
                "getMenuX",   "()F",                      
                (void *) getMenuX
            },								
            {
                "getMenuY",   "()F",                      
                (void *) getMenuY
            },								
            {
                "getMenuW",   "()F",                      
                (void *) getMenuW
            },								
            {
                "getMenuH",   "()F",                      
                (void *) getMenuH
            },								
    		{
    		    "setKey", "(Ljava/lang/String;)V",
    		    (void *) setKey
    		},

            {"initEventClass",  "(Ljava/lang/Object;)V",                     (void*) initEventClass},            
            {"inputcharOnJNI",   "(Ljava/lang/String;)V",                   (void*) inputcharOnJNI},
            {"sendKeyEvent_JNI",   "(II)V",                                 (void*) sendKeyEvent_JNI},
            {"finishComposingText_JNI",   "()V",                           (void*) finishComposingText_JNI},

        };
        return jniRegisterNativeMethods(env, "gui/android/demo/NativeUtils", native_method_table, NELEM(native_method_table));
    }    
}

extern "C" {
    jint JNI_OnLoad(JavaVM *vm, void *reserved) {
        JNIEnv *env = nullptr;
        if (vm->GetEnv((void **) (&env), JNI_VERSION_1_6) != JNI_OK) {
            return -1;
        }
        assert(env != NULL);
        if (!register_native_api(env)) {//注册接口
            return -1;
        }
        if (MGui_jni == nullptr) {
            ::MGui_jni = new AndroidGUI; //加载类
        }    
        return JNI_VERSION_1_6;
    }
}
