package gui.android.demo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.TextView;
import android.provider.Settings;



import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static boolean IsRun = false;
    // 用于在应用程序启动时加载 'native-lib'.
    static {
        System.loadLibrary("gui-native-lib");
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_main);

        if (Integer.parseInt(android.os.Build.VERSION.SDK) >= 31) {
            Toast.makeText(getApplication(), "已检测到您为安卓12 已为您修改信用触摸点！", 0).show();
  	        ShellUtils.execCommand("settings put global block_untrusted_touches 0", true);
        }
        
        if (android.os.Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, 0);
        }

        // 调用本机方法的示例
        final TextView mTextView = (TextView)findViewById(R.id.tv_jni);
        mTextView.setText("Hello gui demo!");

        final Button button1 = findViewById(R.id.my_button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!IsRun) {
                    new WindowStart(getApplicationContext(), false).GOshowFloatWindow();
                    //moveTaskToBack(true);//返回桌面
                    IsRun = true;
                } else {
                    Toast.makeText(getApplicationContext(), "悬浮窗已开启过", Toast.LENGTH_LONG).show();                
                }
            }
        });
        
        final Button button2 = findViewById(R.id.my_button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String apkPath = getApplicationContext().getPackageCodePath();
                String newApkPath = getFilesDir().toString() + "/suApp.apk";
                copyApk(apkPath, newApkPath);
                String libPath = getApplicationContext().getApplicationInfo().nativeLibraryDir;                
                final String cmd = "app_process -Djava.class.path=" + newApkPath + " /system/bin " + Main_process.class.getName() + " " + libPath;
                //Toast.makeText(getApplicationContext(), cmd, Toast.LENGTH_LONG).show();
                new Thread() {
                    @Override
                    public void run() {
  	         	        ShellUtils.execCommand(cmd, true);
                    }                       
                }.start();
            }
        });
        

    }








    public static void copyApk(String sourceApkPath, String destinationApkPath) {
        try {
            // 创建输入流读取APK文件
            FileInputStream fis = new FileInputStream(new File(sourceApkPath));
            // 创建输出流写入新的APK文件
            FileOutputStream fos = new FileOutputStream(new File(destinationApkPath));

            // 缓冲区
            byte[] buffer = new byte[1024];
            int length;

            // 读取文件内容并写入新文件
            while ((length = fis.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }

            // 关闭流
            fis.close();
            fos.close();

            //System.out.println("APK复制成功，复制到：" + destinationApkPath);

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("APK复制失败：" + e.getMessage());
        }
    }


}

