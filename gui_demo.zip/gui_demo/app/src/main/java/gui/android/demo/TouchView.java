package gui.android.demo;

import static android.content.Context.WINDOW_SERVICE;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

public class TouchView extends View {
    static boolean is_app_process;
    static WindowManager F_manager;
    static WindowManager.LayoutParams mtouchParams;
    static View mtouch;
    public static Context mContext;
    static Bundle bundle;
    static InputMethodManager manager;
    static Toast toast;
    static float x, y;
    public TouchView(Context context, WindowManager manager_, boolean is_app_process__) {
        super(context);
        this.mContext = context;
        this.mtouch = this;
        this.F_manager = manager_;
        this.is_app_process = is_app_process__;
        this.bundle = new Bundle();
        this.toast = new Toast(mContext);
        this.manager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        NativeUtils.initEventClass(this);
    }

    public void initView() {
        mtouchParams = WindowManagerLayoutParams.getAttributes(false);
        if (this.is_app_process) {
            mtouchParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_DIALOG;                    
        }
        F_manager.addView(mtouch, mtouchParams);
        updateTouchWinSize();
    }

    int action;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        NativeUtils.navateInputEvent(event);
        return false;
    }

    public void updateTouchWinSize() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    mtouchParams.x = (int) NativeUtils.getMenuX();
                    mtouchParams.y = (int) NativeUtils.getMenuY();
                    mtouchParams.width = (int) NativeUtils.getMenuW();
                    mtouchParams.height = (int) NativeUtils.getMenuH();
                    F_manager.updateViewLayout(mtouch, mtouchParams);
                } catch (Exception e) {
                }
                handler.postDelayed(this, 20);
            }
        }, 20);
    }


    @Override
    public boolean onCheckIsTextEditor() {
        return true;
    }

    //方法，需要返回一个InputConnect对象，这个是和输入法输入内容的桥梁。
    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        // outAttrs就是我们需要设置的输入法的各种类型最重要的就是:
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN;
        outAttrs.inputType = InputType.TYPE_TEXT_FLAG_AUTO_CORRECT | InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE |InputType.TYPE_MASK_FLAGS ;
        return new MyInputConnection(this,true);
    }

    /**
     * 重写BaseInputConnection获取输入法按键KEY以及输入内容
     */
    class MyInputConnection extends BaseInputConnection {
        //一般我们都是些一个BaseInputConnection的子类，而BaseInputConnection是实现InputConnection接口的。

        //需要注意的就是几个方法注意重写。
        public MyInputConnection(View targetView, boolean fullEditor) {
            super(targetView, fullEditor);
        }


        /**
         * @param text 获取按键输入内容，中文输入模式不可用
         * @param newCursorPosition 输入光标偏移，通常为1，如果为0无输入
         * @return
         */
        @Override
        public boolean setComposingText(CharSequence text, int newCursorPosition) {
            //note:获取到输入的字符
            Log.e("NDK", "setComposingText:" + text + "\t" + newCursorPosition);
            postInvalidate();
            return true;
        }


        /**
         * @param text 选择输入法候选栏输入字符
         * @param newCursorPosition 通常为1
         * @return
         */
        @Override
        public boolean commitText(CharSequence text, int newCursorPosition) {
            //note:获取到输入的字符
            Log.e("NDK", "commitText:" + text + "\t" + newCursorPosition);
            NativeUtils.inputcharOnJNI(text.toString());
            postInvalidate();
            return true;
        }


        /**
         * @param event 获取按键KeyEvent
         * @return
         */
        @Override
        public boolean sendKeyEvent(KeyEvent event) {
            /** 当手指离开的按键的时候 */
            NativeUtils.sendKeyEvent_JNI(event.getAction(), event.getKeyCode());
            Log.e("NDK", "sendKeyEvent:KeyCode=" + event.getKeyCode());
            postInvalidate();
            return true;
        }

        //当然删除的时候也会触发
        @Override
        public boolean deleteSurroundingText(int beforeLength, int afterLength) {
            Log.e("NDK", "deleteSurroundingText " + "beforeLength=" + beforeLength + " afterLength=" + afterLength);

            return true;
        }

        /**
         * @return 手动关闭输入法，结束输入
         */
        @Override
        public boolean finishComposingText() {
            //结束组合文本输入的时候，这个方法基本上会出现在切换输入法类型，点击回车（完成、搜索、发送、下一步）点击输入法右上角隐藏按钮会触发。
            Log.e("NDK", "finishComposingText");
            NativeUtils.finishComposingText_JNI();
            return true;
        }
    }

    @SuppressLint("HandlerLeak")
    public static Handler handlerm = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            int[] io = new int[2];
            if ((io = msg.getData().getIntArray("psio")) != null) {
                ioset(io);
            }
        }
    };
    public static void ioset(int[] io) {
        switch (io[0]) {
            case 2: {
                if (io[1] == 1) {
                    setmyFocusable(true);
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException exception) {
                        exception.printStackTrace();
                    }
                    openInput();
                }else {
                    closeInput();
                    setmyFocusable(false);
                }
            }
            break;
            case 5: {
                if ( io[1] == 1 ){
                    //FloatService.surfaceView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS,HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                }else {
                    //FloatService.surfaceView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS,HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                }
            }
            break;
            case 3: {
                isLongTouch((int)x,(int)y);
            }
            break;
        }
    }


    public static void mIO(String psmsg,int pos, int io){
        int[] ioi = new int[2];
        ioi[0] = pos;
        ioi[1] = io;
        if (io>100){
            ioi[1] -= 100;
            //FloatService.surfaceView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS,HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
        }
        Message message = handlerm.obtainMessage();

//        Log.e("NDK","ioset"+"pos="+pos+"io="+io);
        bundle.putIntArray(psmsg,ioi);
        message.setData(bundle);//通过setData将字符串发送
        handlerm.sendMessage(message);

    }

    @SuppressLint("HandlerLeak")
    public static Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            toast = Toast.makeText(mContext, msg.getData().getString("JNI_msg") , Toast.LENGTH_SHORT);
            toast.show();
        };
    };

    public static void mShow(String msg){
        Message message = handler.obtainMessage();
        bundle.putString("JNI_msg",msg);
        message.setData(bundle);
        handler.sendMessage(message);
    }


    public static void setmyFocusable(boolean o){
        if (o){
            mtouchParams.flags  =WindowManager.LayoutParams.FLAG_FULLSCREEN
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION
//                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                    |WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }else {
            mtouchParams.flags  =WindowManager.LayoutParams.FLAG_FULLSCREEN
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                    |WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }
        F_manager.updateViewLayout(mtouch, mtouchParams);
    }
    static boolean Inputio = false;
    /**
     * 如果输入法关，则开启输入法
     */
    public static boolean openInput(){
        if (!Inputio){
            setmyFocusable(true);
            Log.e("NDK", "唤醒输入法");
            //        获取 接受焦点的资格
            mtouch.setFocusable(true);
            //        获取 焦点可以响应点触的资格
            mtouch.setFocusableInTouchMode(true);
            //        请求焦点
            boolean ck = mtouch.requestFocus();
            Log.e("NDK","requestFocus:"+ck);
            //        弹出键盘
            ck = manager.showSoftInput(mtouch, InputMethodManager.SHOW_FORCED);
//            manager.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
            Log.e("NDK","showSoftInput:"+ck);
            if (manager.isActive()) {
                Inputio = true;
                Log.e("NDK", "唤醒输入法成功");
                mtouch.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS,HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                return Inputio;
            } else {
                NativeUtils.finishComposingText_JNI();
                Log.e("NDK", "唤醒输入法失败");
                return Inputio;
            }
        }
        return Inputio;
    }

    /**
     * 如果输入法开，则关闭输入法
     */
    public static boolean closeInput(){
        if (Inputio){
            Log.e("NDK", "关闭输入法");
            //        取消焦点
            mtouch.setFocusable(false);
            //        取消 焦点可以响应点触的资格
            mtouch.setFocusableInTouchMode(false);
            //       清除焦点
            mtouch.clearFocus();
            //       隐藏悬浮窗
            manager.hideSoftInputFromWindow(mtouch.getWindowToken(), 0);

            if (manager.isActive()) {
                Inputio = false;
                setmyFocusable(false);
                mtouch.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS,HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                Log.e("NDK", "关闭输入法成功");
            } else {
                Log.e("NDK", "关闭输入法失败");
            }
            return Inputio;
        }
        return Inputio;
    }

    public static void isLongTouch(int x,int y){
        mtouch.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS,HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
        //FloatService.Show_mFloatButton((int)x,(int)y);
        mtouch.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS,HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
    }


}
