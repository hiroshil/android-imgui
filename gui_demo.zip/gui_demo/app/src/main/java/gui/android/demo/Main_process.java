package gui.android.demo;

import android.os.Looper;
import android.os.Build;
import android.os.Process;
import android.content.Context;
import java.lang.reflect.Method;
import java.io.PrintStream;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import android.content.Intent;


public class Main_process {
    public static void main(String[] args) {
        
        try {
            System.setOut(new PrintStream(new FileOutputStream("/storage/emulated/0/output.txt")));
            System.setErr(new PrintStream(new FileOutputStream("/storage/emulated/0/error.txt")));
            System.out.println("This is redirected to output.txt");
            System.err.println("This is redirected to error.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
        if (args.length != 1) {
            System.exit(1);
        }
        if (Integer.parseInt(android.os.Build.VERSION.SDK) >= 31) {
            try {
                Runtime.getRuntime().exec("settings put global block_untrusted_touches 0");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        System.load(args[0] + "/lib" + "gui-native-lib" + ".so");
        
        Looper.prepareMainLooper();
        int sdk_Api = Build.VERSION.SDK_INT;
        System.out.println("<+>当前pid : " + Process.myPid());
        System.out.println("<+>当前uid : " + Process.myUid());
        System.out.println("<+>apiLevel : " + sdk_Api);

        //System.err.close(); 
        Context UI_context = getViewContext();
        //System.setErr(new PrintStream(new FileOutputStream(FileDescriptor.err)));
        if (UI_context == null) {
            System.err.println("UI_context null err"); 
            return;
        }
        System.out.println("ok"); 

        new WindowStart(UI_context, true).GOshowFloatWindow();
        Looper.loop();
    }
    
    public static Context getViewContext() {
        Context ViewContext = null;
        try {
            final Class<?> ActivityThread_class = Class.forName("android.app.ActivityThread");  
            final Method systemMain_hod = ActivityThread_class.getMethod("systemMain", new Class[0]);  
            final String FunctionName = Build.VERSION.SDK_INT >= 26 ? "getSystemUiContext" : "getSystemContext"; //前者等于安卓8.0或者大于
            final Method getSystemContext_hod = ActivityThread_class.getMethod(FunctionName, new Class[0]);                                  
            final Object ActivityThread_obj = systemMain_hod.invoke(ActivityThread_class);
            final Context sys_context = (Context)getSystemContext_hod.invoke(ActivityThread_obj);
            ViewContext = sys_context.createPackageContext("com.android.systemui", 0);//Context.CONTEXT_IGNORE_SECURITY | Context.CONTEXT_INCLUDE_CODE);       
            //ViewContext = sys_context.createPackageContext("com.android.shell", Context.CONTEXT_IGNORE_SECURITY | Context.CONTEXT_INCLUDE_CODE);       
        } catch (Exception e) {
            throw new RuntimeException(e);
        }                       
        return ViewContext;
    }
}
