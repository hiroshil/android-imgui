package gui.android.demo;

import android.content.Context;
import android.os.RemoteException;
import android.graphics.PixelFormat;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.view.View;



public final class SV extends SurfaceView implements SurfaceHolder.Callback {
    public SV(Context context) {
        super(context);
        /*
 		this.setZOrderOnTop(true);
        this.getHolder().setFormat(PixelFormat.RGBA_8888);
        this.getHolder().addCallback(this);
        */
        this.setZOrderOnTop(true);
        this.getHolder().setFormat(PixelFormat.RGBA_8888);
        this.getHolder().addCallback(this);
        this.setFocusable(true);
        this.setFocusableInTouchMode(true);
        this.requestFocus();
        this.requestFocusFromTouch();     
           
       
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        NativeUtils.setSurface(holder.getSurface());
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        NativeUtils.start(width, height);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
    }
}
