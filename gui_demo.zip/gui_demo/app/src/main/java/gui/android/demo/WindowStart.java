package gui.android.demo;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import java.util.HashMap;
import java.util.Map;
import android.view.inputmethod.InputMethodManager;

import android.view.SurfaceControl;
public class WindowStart {
    private Map<Integer, View> TouchViewList_;
    private boolean is_app_process;
	private Context Mcontext;
    private WindowManager manager;
    private WindowManager.LayoutParams surfaceView_Params;
    private WindowManager.LayoutParams surfaceTouch_Params;
    private SurfaceView surfaceView;
	private SurfaceView surfaceTouch;
    
	public WindowStart(Context context, boolean is_app_process) {
	    this.Mcontext = context;
	    this.is_app_process = is_app_process;
	}
	
	public void GOshowFloatWindow() {
        this.manager = (WindowManager) this.Mcontext.getSystemService(Context.WINDOW_SERVICE);
        this.surfaceView_Params = new WindowManager.LayoutParams();
        
        surfaceView_Params.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
			View.SYSTEM_UI_FLAG_FULLSCREEN |
			View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
			View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
			View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
			View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
		
        if (this.is_app_process) {
            surfaceView_Params.type = WindowManager.LayoutParams.TYPE_SYSTEM_DIALOG;            
        } else {
            surfaceView_Params.type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;        
        }
        
        surfaceView_Params.gravity = Gravity.TOP | Gravity.LEFT;
        surfaceView_Params.format = PixelFormat.RGBA_8888;
        surfaceView_Params.width = WindowManager.LayoutParams.MATCH_PARENT;
        surfaceView_Params.height = WindowManager.LayoutParams.MATCH_PARENT;
        surfaceView_Params.flags = //WindowManager.LayoutParams.FLAG_SECURE |//防截屏
			//WindowManager.LayoutParams.FLAG_DITHER | //抖动(过录屏)
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | //布局充满整个屏幕 忽略应用窗口限制
			WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |//不接受触控
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | //不接受焦点
			//WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | //允许有触摸属性
            //WindowManager.LayoutParams.FLAG_SPLIT_TOUCH | //接受多点触控
			WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED; //硬件加速
			//WindowManager.LayoutParams.FLAG_FULLSCREEN; //隐藏状态栏导航栏以全屏(貌似没什么用)
			//WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |//忽略屏幕边界
			//WindowManager.LayoutParams.FLAG_LAYOUT_ATTACHED_IN_DECOR |//显示在状态栏上方(貌似高版本无效
     //   SurfaceControl.SKIP_SCREENSHOT;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            surfaceView_Params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;//覆盖刘海
        }

        this.surfaceTouch_Params = new WindowManager.LayoutParams();
        if (this.is_app_process) {
            surfaceTouch_Params.type = WindowManager.LayoutParams.TYPE_SYSTEM_DIALOG;            
        } else {
            surfaceTouch_Params.type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;        
        }
        surfaceTouch_Params.gravity = Gravity.TOP | Gravity.LEFT;
        surfaceTouch_Params.format = PixelFormat.RGBA_8888;
        surfaceTouch_Params.width = 770;
        surfaceTouch_Params.height = 780;
        surfaceTouch_Params.x = 60;
        surfaceTouch_Params.y = 60;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            surfaceTouch_Params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;//覆盖刘海
        }
        surfaceTouch_Params.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN; //布局充满整个屏幕 忽略应用窗口限制
        surfaceTouch_Params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; //不接受焦点
        surfaceTouch_Params.flags |= WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED; //硬件加速
			//WindowManager.LayoutParams.FLAG_SECURE |//防截屏
			//WindowManager.LayoutParams.FLAG_DITHER | //抖动(过录屏)
            //WindowManager.LayoutParams.FLAG_SPLIT_TOUCH |
			//WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
			
			//WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |//忽略屏幕边界
			//WindowManager.LayoutParams.FLAG_LAYOUT_ATTACHED_IN_DECOR;//显示在状态栏上方(貌似高版本无效

        
		this.surfaceView = new SV(this.Mcontext);
		manager.addView(surfaceView, surfaceView_Params);
		
        TouchView mtouch = new TouchView(this.Mcontext, manager, this.is_app_process);
        mtouch.initView();
		/*
        int fl = 1;
        if (fl == 1) {
            updateTouchWinSize();        
        } else if (fl == 0) {
            this.surfaceTouch = new SurfaceView(this.Mcontext);
		    //surfaceTouch.setBackgroundColor(0xffffffff);
            surfaceTouch.setZOrderOnTop(true);
            surfaceTouch.getHolder().setFormat(PixelFormat.RGBA_8888);
            surfaceTouch.setOnTouchListener(new MonitorTouchView_a1());
		    manager.addView(surfaceTouch, surfaceTouch_Params);
		    updateTouchWinSize_a1();
        }
        */
        
    }

	
    public void updateTouchWinSize_a1() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
						int x = (int)NativeUtils.getMenuX();
						int y = (int)NativeUtils.getMenuY();
						int w = (int)NativeUtils.getMenuW();
						int	h = (int)NativeUtils.getMenuH();
						
						surfaceTouch_Params.x = x;
						surfaceTouch_Params.y = y;
						surfaceTouch_Params.width = w;
					    surfaceTouch_Params.height = h;

						manager.updateViewLayout(surfaceTouch, surfaceTouch_Params);
                } catch (Exception e) {
                }
                handler.postDelayed(this, 20);
            }
        }, 20);
    }
    
	
		
    //更新窗口信息
    public void updateTouchWinSize() {
        this.TouchViewList_ = new HashMap<>();//创建view表
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    //有bug联系我，有时间会修复的 1486609722 记得备注原因
                    CallData[] cd = NativeUtils.GetImguiwinsize(CallData.class);
                    //Log.e("NDK-java","收到宽高: W:"+cd[0].X1+" H:"+cd[0].Y1);
                    for (int i = 0; i < cd.length; i++) {
                        surfaceTouch_Params.x = (int) cd[i].X;
                        surfaceTouch_Params.y = (int) cd[i].Y;
                        surfaceTouch_Params.width = (int) cd[i].X1;
                        surfaceTouch_Params.height = (int) cd[i].Y1;

                        if (TouchViewList_.isEmpty()) {                            
                            if (!cd[i].WinName.equals("Debug##Default")) {//过滤debug窗口
                                MonitorTouchView mtouch = new MonitorTouchView(Mcontext);
                                TouchViewList_.put(cd[i].ID, mtouch);
                                manager.addView(mtouch, surfaceTouch_Params);
                            } else {
                                //Log.e("NDK-java","检测到Debug窗口");
                            }
                        } else if (!TouchViewList_.containsKey(cd[i].ID)) {
                            if (!cd[i].WinName.equals("Debug##Default")) {
                                MonitorTouchView mtouch = new MonitorTouchView(Mcontext);
                                TouchViewList_.put(cd[i].ID,mtouch);
                                manager.addView(mtouch, surfaceTouch_Params);
                            } else {
                                //Log.e("NDK-java","检测到Debug窗口");
                            }
                        } else {
                            //Log.e("NDK-java","悬浮窗宽高: W:"+TouchViewList_.get(cd[i].ID).getWidth()+" H:"+TouchViewList_.get(cd[i].ID).getHeight());
                           // Log.e("NDK-java", "窗口数据: 窗口名字:"+cd[i].WinName+ " X:"+cd[i].X+" Y"+cd[i].Y+" X1"+cd[i].X1+" Y1"+cd[i].Y1);
                            if (!cd[i].Action) {//如果不处于活动状态说明窗口隐藏了
                                surfaceTouch_Params.width = 0;
                                surfaceTouch_Params.height = 0;
                            }
                            manager.updateViewLayout(TouchViewList_.get(cd[i].ID), surfaceTouch_Params);
                        }
                    }                        
                    for (int key : TouchViewList_.keySet()) {//循环判断获取的列表和本地列表key是否一致
                        boolean ba = false;
                        for (int i = 0; i < cd.length; i++) {
                            if (key == cd[i].ID) {
                                ba = true;
                            }
                        }
                        
                        if (ba == false) {//如果不等于就说明有个窗口被删掉了，就从map和窗口里面移除
                            manager.removeView(TouchViewList_.get(key));
                            TouchViewList_.remove(key);
                            Log.e("NDK-java","删除窗口");
                        }
                    }
                } catch (Exception e) {
                    Log.e("NDK-java", "跳出");
                }
                handler.postDelayed(this, 20);
            }
        }, 20);
    }




    private class MonitorTouchView extends View {
        public Context mContext;

        public MonitorTouchView(Context context) {
            super(context);
            mContext = context;
        }
        
        @Override
        public boolean onTouchEvent(MotionEvent event) {
            NativeUtils.navateInputEvent(event);
            return false;
        }
    }

    private class MonitorTouchView_a1 implements View.OnTouchListener {
        public MonitorTouchView_a1() {
        }
        
        @Override
        public boolean onTouch(View view, MotionEvent event) {
            NativeUtils.navateInputEvent(event);
            return false;
        }
    }


}
