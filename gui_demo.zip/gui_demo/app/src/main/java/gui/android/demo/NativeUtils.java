package gui.android.demo;

import android.view.MotionEvent;
import android.view.Surface;
import java.util.UUID;

public class NativeUtils {
    public static native void setSurface(Surface surface);
    public static native String start(int ScreenX, int ScreenY);
    public static native void navateInputEvent(MotionEvent motionEvent);
    public static native CallData[] GetImguiwinsize(Class<?> call);
    public static native float getMenuW();
    public static native float getMenuH();
    public static native float getMenuX();
    public static native float getMenuY();
	public static native void setKey(String key);

    public static native void initEventClass(Object classObj);
    public static native void inputcharOnJNI(String msg);
    public static native void sendKeyEvent_JNI(int action, int code);
    public static native void finishComposingText_JNI();
    
}
