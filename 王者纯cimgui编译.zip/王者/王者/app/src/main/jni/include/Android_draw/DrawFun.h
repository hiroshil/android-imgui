//#include "Menu.h"
//交流群769774765
#include "结构体.h"
#include "裸奔读写.h"
#include "stb_image.h"
ImColor TextColor   = ImColor(1.0f, 1.0f, 1.0f, 1.0f);
float   LineThickness = 1.0f;
ImColor LineColor     = ImColor(1.0f, 0.0f, 0.0f, 1.0f);

//默认颜色
ImColor LinesColor     = ImColor(1.0f, 1.0f, 0.0f, 1.0f);
//默认宽度
float   LinesThickness = 2.0f;
//默认颜色
ImColor RectColor     = ImColor(1.0f, 0.0f, 0.0f, 1.0f);
 //默认宽度
float   RectThickness = 2.0f;
//默认圆角
float   RectRounding  = 0.0f;
const ImU32 物资色 = ImColor(0xFFBB8ADF);


/*********自己的绘制函数***********/
//画圆弧函数
//ImGui::GetBackgroundDrawList()->PathArcToFast(ImVec2(400,200),100 ,0,10);


TextureInfo createTexture(char* ImagePath)
{
	TextureInfo textureInfo;
	int w,h,n;
	stbi_uc * data = stbi_load(ImagePath,&w,&h,&n,0);
	GLuint texture;
	glGenTextures(1, &texture);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	if(n==3)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w , h , 0, GL_RGB, GL_UNSIGNED_BYTE, data);
	} else{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w , h , 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
	}
	stbi_image_free(data);
	textureInfo.textureId=(GLuint)texture;
	textureInfo.w=w;
	textureInfo.h=h;
	return textureInfo;
}

TextureInfo 获取头像(int 次数)
{
	char 路径[1024];
	sprintf(路径,"/sdcard/图片/%d.png",次数);
	return createTexture(路径);
}

struct 全部头像{
	TextureInfo 头像[650];
	
};
全部头像 贴图;


void 获取头像(){
	for(int i = 0;i<622;i+=1){
		贴图.头像[i] = 获取头像(i);
	}
}

void 绘制头像(TextureInfo textureInfo,int x, int y){
	ImGui::GetBackgroundDrawList()->AddImage(textureInfo.textureId, ImVec2(x-textureInfo.w/2, y -textureInfo.y), ImVec2(x-textureInfo.w/2 + textureInfo.w/2.55, y-textureInfo.y + textureInfo.h/2.55));
}

void 绘制血条(float leftx,float lefty,int hp){
	// ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(upper_leftX, upper_leftY), ImVec2(lower_rightX, lower_rightY), ImColor(队伍颜色(dw)), 0);
	float TXdx = 0.020834f*(py*2);
	float cc = TXdx*1.10f;
	
	ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(leftx-cc,lefty+TXdx),ImVec2(leftx+cc,lefty+TXdx+7),Color.白色,3,ImDrawFlags_RoundCornersAll);
	ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(leftx-cc,lefty+TXdx),ImVec2(leftx-cc+hp*cc/50-0.5f,lefty+TXdx+7),Color.Green,2,ImDrawFlags_RoundCornersAll);
}

void 绘制四角方框(float x, float y, float w ){
	
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(x-(w/2), y+(w/1)), ImVec2(x+(w/4)-w/2, y+(w/1)), ESPMenu.实体颜色,4);
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(x+(w/2), y+(w/1)), ImVec2(x-(w/4)+w/2, y+(w/1)), ESPMenu.实体颜色,4);
    ImGui::GetBackgroundDrawList()->AddLine(ImVec2(x-(w/2), y-(w/1)), ImVec2(x+(w/4)-w/2, y-(w/1)), ESPMenu.实体颜色,4);
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(x+(w/2), y-(w/1)), ImVec2(x-(w/4)+w/2, y-(w/1)), ESPMenu.实体颜色,4);
	
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(x+(w/2), y-(w/1)), ImVec2(x-(w/2)+w/1, y-(w/2)), ESPMenu.实体颜色,4);
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(x+(w/2), y+(w/1)), ImVec2(x-(w/2)+w/1, y+(w/2)), ESPMenu.实体颜色,4);
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(x-(w/2), y-(w/1)), ImVec2(x+(w/2)-w/1, y-(w/2)), ESPMenu.实体颜色,4);
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(x-(w/2), y+(w/1)), ImVec2(x+(w/2)-w/1, y+(w/2)), ESPMenu.实体颜色,4);
	
}

void 绘制技能(TextureInfo textureInfo,int x,int y,int 大招CD,int 技能CD){
	ImGui::GetBackgroundDrawList()->AddImage(textureInfo.textureId,ImVec2(x-textureInfo.w/2,y-textureInfo.y),ImVec2(x-textureInfo.w/2+textureInfo.w/2,y-textureInfo.y+textureInfo.h/2));
	
	char 大招计时[64];
	sprintf(大招计时,"%d",大招CD);
	
	char 技能计时[64];
	sprintf(技能计时,"%d",技能CD);
	
	ImGui::GetBackgroundDrawList()->AddText(NULL,30.f,ImVec2(800.f,73.f),Color.白色,"大招");
	ImGui::GetBackgroundDrawList()->AddText(NULL,30.f,ImVec2(800.f,116.f),Color.白色,"技能");
	
	if(大招CD!=0){
		ImGui::GetBackgroundDrawList()->AddText(NULL,30.f,ImVec2(x-43,y+70),Color.白色,大招计时);
	}else{
		ImGui::GetBackgroundDrawList()->AddCircleFilled({x-30,y+82},13,Color.Green);
	}
	if(技能CD!=0){
		ImGui::GetBackgroundDrawList()->AddText(NULL,30.f,ImVec2(x-43,y+113),Color.白色,技能计时);
	}else{
		ImGui::GetBackgroundDrawList()->AddCircleFilled({x-30,y+125},13.f,Color.Green);
	}
}

void 绘制兵线(int x,int y){
    ImGui::GetBackgroundDrawList()->AddCircleFilled({x,y},4.f,ESPMenu.兵线颜色);   
}

void 绘制野怪计时(int X, int Y, const char *data) {
    ImGui::GetBackgroundDrawList()->AddText(NULL, 24.f, ImVec2(X-4, Y-8), ESPMenu.野怪颜色,data);
}

void 绘制野怪(int x,int y){
    ImGui::GetBackgroundDrawList()->AddCircleFilled({x,y},8.f,ESPMenu.野怪颜色);   
}

void 绘制射线(float startx, float starty, float endx, float endy){
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(startx, starty), ImVec2(endx, endy), ESPMenu.射线颜色,3);
    ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(startx ,starty),5.f,ESPMenu.射线颜色);
}

void 绘制实体方框(float leftx, float lefty, float rightx, float righty) {
	
	
	ImGui::GetBackgroundDrawList()->AddRect(ImVec2(leftx, lefty), ImVec2(rightx, righty), ESPMenu.实体颜色, 6, ImDrawFlags_RoundCornersAll, 5.0f);
   
	//ImGui::GetBackgroundDrawList()->AddRect(ImVec2(leftx-rightx+40, lefty-rightx), ImVec2(leftx+rightx-20, lefty+rightx-40), ESPMenu.实体颜色, 10, ImDrawFlags_RoundCornersAll, 5.0f);
}


void 绘制实体头像(TextureInfo textureInfo,int x, int y){
	ImGui::GetBackgroundDrawList()->AddImage(textureInfo.textureId, ImVec2(x-textureInfo.w/2, y -textureInfo.y), ImVec2(x-textureInfo.w/2 + textureInfo.w/2, y-textureInfo.y + textureInfo.h/2));
}



