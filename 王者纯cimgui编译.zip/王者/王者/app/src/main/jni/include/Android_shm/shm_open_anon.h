// From https://github.com/lassik/shm_open_anon
#ifndef NATIVESURFACE_SHM_H
#define NATIVESURFACE_SHM_H
int shm_open_anon(void);
#endif