#include <string>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <malloc.h>
#include <math.h>
#include <thread>
#include <iostream>
#include <sys/stat.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <iostream>
#include <locale>
#include <string>
#include <codecvt>
#include <dlfcn.h>
#include <stdlib.h>
#include <string>
#include <stdio.h>				// 基本头文件
#include <dirent.h>				// 获取PID需要的
#include <stdlib.h>				// 获取PID需要的(atoi)
#include <math.h>				// 取绝对值(float)
#include <unistd.h>				// 读取数据
#include <sys/uio.h>			// 读取数据
#include <sys/syscall.h>		// 读取数据
#include <stdlib.h>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <thread>
#include <iostream>

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/socket.h>
#include <malloc.h>
#include <math.h>
#include <thread>
#include <iostream>
#include <sys/stat.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <iostream>
#include <locale>
#include <string>
#include <codecvt>
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/uio.h>
#include <iostream>
#include <fstream>

using namespace std;
uintptr_t libbase, Selfaddr,Gname, Uworld, Arrayaddr, Matrix, Objaddr, Object, Mesh, Human, Bone, Uleve;
uintptr_t GNames;
uintptr_t GWorld;
uintptr_t Getmatrix;
typedef long ADDRESS;
typedef char PACKAGENAME;
typedef unsigned short UTF16;
typedef char UTF8;
float px,py;
char lj[64];

int isSize = 4;//默认32位

char *结束时间;


int pid;
#if defined(__arm__)
int process_vm_readv_syscall = 376;
int process_vm_writev_syscall = 377;
#elif defined(__aarch64__)
int process_vm_readv_syscall = 270;
int process_vm_writev_syscall = 271;
#elif defined(__i386__)
int process_vm_readv_syscall = 347;
int process_vm_writev_syscall = 348;
#else
int process_vm_readv_syscall = 310;
int process_vm_writev_syscall = 311;
#endif

void readBuffer(long addr,void*buffer,int size)// 读取核心函数
{
	struct iovec iov_ReadBuffer,iov_ReadOffset;
	iov_ReadBuffer.iov_base = buffer;
	iov_ReadBuffer.iov_len = size;
	iov_ReadOffset.iov_base = (void*)addr;
	iov_ReadOffset.iov_len = size;
	syscall(SYS_process_vm_readv,pid,&iov_ReadBuffer,1,&iov_ReadOffset,1,0);
}

int readDword(long address)// 传输地址(读)一个int D类型
{
	int value = 0;
	int*p = &value;
	readBuffer(address,p,sizeof(int));
	return value;
}

float readFloat(long address)// 传输地址(读)一个int F类型
{
	float value = 0.0;
	float*p = &value;
	readBuffer(address,p,sizeof(float));
	return value;
}

long readValueL(long address)// 传输地址(读) 指针跳转
{
	long addr = 0;
	long*p = &addr;
	readBuffer(address,p,sizeof(long));
	return addr&0xFFFFFFFFFF;
}
// 获取基址
uintptr_t basea = 0;

uintptr_t getModuleBase(const char *module_name)
{
    FILE *fp;
    long addr = 0;
    char *pch;
    char filename[64];
    char line[1024];
    snprintf(filename, sizeof(filename), "/proc/self/maps");
    fp = fopen(filename, "r");
    if (fp != NULL)
    {
        while (fgets(line, sizeof(line), fp))
        {
            if (strstr(line, module_name))
            {
                pch = strtok(line, "-");
                addr = strtoul(pch, NULL, 16);
                if (addr == 0x8000)
                    addr = 0;
                break;
            }
        }
        fclose(fp);
    }
    return addr;
}
// 获取进程是否运行



// 写入F类内存


// 



// 获取基址
long getModuleBase(pid_t PID,char*module_name)
{
	char*phgsr;
	char jjjj_N[64];
	long startaddr = 0;
	char path[256],line[1024];
	bool bssOF = false,LastIsSo = false;
	strcpy(jjjj_N,module_name);
	phgsr = strtok(jjjj_N,":");
	module_name = phgsr;
	phgsr = strtok(NULL,":");
	if(phgsr)
	{
		if(strcmp(phgsr,"bss")==0)
		{
			bssOF = true;
		}
	}
	sprintf(path,"/proc/%d/maps",PID);
	FILE*p = fopen(path,"r");
	if(p)
	{
		while(fgets(line,sizeof(line),p))
		{
			if(LastIsSo)
			{
				if(strstr(line,"[anon:.bss]")!=NULL)
				{
					sscanf(line,"%lx-%*lx",&startaddr);
					break;
				}
				else
				{
					LastIsSo = false;
				}
			}
			if(strstr(line,module_name)!=NULL)
			{
				if(!bssOF)
				{
					sscanf(line,"%lx-%*lx",&startaddr);
					break;
				}
				else
				{
					LastIsSo = true;
				}
			}
		}
		fclose(p);
	}
	return startaddr;
}

int getProcessID(const char *packageName)
{
    int id = -1;
    DIR *dir;
    FILE *fp;
    char filename[64];
    char cmdline[64];
    struct dirent *entry;
    dir = opendir("/proc");
    while ((entry = readdir(dir)) != NULL)
    {
        id = atoi(entry->d_name);
        if (id != 0)
        {
            sprintf(filename, "/proc/%d/cmdline", id);
            fp = fopen(filename, "r");
            if (fp)
            {
                fgets(cmdline, sizeof(cmdline), fp);
                fclose(fp);
                if (strcmp(packageName, cmdline) == 0)
                {
                    return id;
                }
            }
        }
    }
    closedir(dir);
    return -1;
}






