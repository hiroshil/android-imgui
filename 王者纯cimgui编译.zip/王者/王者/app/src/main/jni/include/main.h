//
// Created by Ssage on 2022/3/18.
//
#ifndef SSAGEPARUDERS_NATIVE_SURFACE_H
#define SSAGEPARUDERS_NATIVE_SURFACE_H
// User libs
#include <draw.h>
#include <touch.h>
// Func
void tick(bool *flag);
#endif //SSAGEPARUDERS_NATIVE_SURFACE_H