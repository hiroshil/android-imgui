#ifndef 结构体
#define 结构体
#include <string>

struct Vec3 {
    float x, y, z;
};
class Vec2 {
public:
    float x;
    float y;

    Vec2() {
        this->x = 0;
        this->y = 0;
    }

    Vec2(float x, float y) {
        this->x = x;
        this->y = y;
    }

    static Vec2 Zero() {
        return Vec2(0.0f, 0.0f);
    }

    bool operator!=(const Vec2 &src) const {
        return (src.x != x) || (src.y != y);
    }

    Vec2 &operator+=(const Vec2 &v) {
        x += v.x;
        y += v.y;
        return *this;
    }

    Vec2 &operator-=(const Vec2 &v) {
        x -= v.x;
        y -= v.y;
        return *this;
    }
};

static struct Color{
	ImColor Red={255/255.f,0/255.f,0/255.f,255/255.f};
	ImColor Red_={255/255.f,0/255.f,0/255.f,50/255.f};
	ImColor Green={0/255.f,255/255.f,0/255.f,255/255.f};
	ImColor Green_={0/255.f,255/255.f,0/255.f,50/255.f};
	ImColor 白色={255/255.f,255/255.f,255/255.f,255.f/255.f};
    ImColor White_={255/255.f,255/255.f,255/255.f,180.f/255.f};
    ImColor Black={0/255.f,0/255.f,0/255.f,255.f/255.f};
	ImColor Yellow={1.0f, 1.0f, 0.0f,1.0f};
}Color;

struct TextureInfo{
    ImTextureID textureId;
    int x;
    int y;
    int w;
    int h;
};


struct sESPMenu {	
	bool 显示头像;
	bool 显示射线;
	bool 圆角方框;
	bool 四角方框;
	bool 实体头像;
	bool 技能计时;
	bool 野怪计时;
	bool 显示兵线;
	int 小地图左右调整=126;
	int 小地图上下调整=4;
	int 实体左右调整=0;
	int 实体上下调整=0;
    bool 信息;
	int FPS帧率=60;
	
	ImColor 实体颜色 = {1.0f, 1.0f, 1.0f, 1.0f};
	ImColor 射线颜色 = {1.0f, 1.0f, 1.0f, 1.0f};
	ImColor 野怪颜色 = {1.0f, 1.0f, 1.0f, 1.0f};
	ImColor 兵线颜色 = {1.0f, 1.0f, 1.0f, 1.0f};
	
};
sESPMenu ESPMenu;


#endif
