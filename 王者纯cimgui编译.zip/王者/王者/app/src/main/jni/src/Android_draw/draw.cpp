//
// Created by 泓清 on 2022/8/26.
//

#include <draw.h>
//交流群769774765
// Var
void *handle;// 动态库方案
EGLDisplay display = EGL_NO_DISPLAY;
EGLConfig config;
EGLSurface surface = EGL_NO_SURFACE;
ANativeWindow *native_window;
ANativeWindow *(*createNativeWindow)(const char *surface_name, uint32_t screen_width, uint32_t screen_height, bool author);
EGLContext context = EGL_NO_CONTEXT;

Screen full_screen;
int Orientation = 0;
int screen_x = 0, screen_y = 0;
int init_screen_x = 0, init_screen_y = 0;
bool g_Initialized = false;

string exec(string command) {
    char buffer[128];
    string result = "";
    // Open pipe to file
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return "popen failed!";
    }
    // read till end of process:
    while (!feof(pipe)) {
        // use buffer to read and add to result
        if (fgets(buffer, 128, pipe) != nullptr){
            result += buffer;
        }
    }
    pclose(pipe);
    return result;
}

int init_egl(int _screen_x, int _screen_y, bool log){
    void* sy = get_createNativeWindow(); // 适配9-13安卓版本
    createNativeWindow = (ANativeWindow *(*)(const char *, uint32_t, uint32_t, bool))(sy);
    native_window = createNativeWindow("Ssage", _screen_x, _screen_y, true);
    ANativeWindow_acquire(native_window);
    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        printf("eglGetDisplay error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglGetDisplay ok\n");
    }
    if (eglInitialize(display, 0, 0) != EGL_TRUE) {
        printf("eglInitialize error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglInitialize ok\n");
    }
    EGLint num_config = 0;
    const EGLint attribList[] = {
            EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
            EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
            EGL_BLUE_SIZE, 5,   //-->delete
            EGL_GREEN_SIZE, 6,  //-->delete
            EGL_RED_SIZE, 5,    //-->delete
            EGL_BUFFER_SIZE, 32,  //-->new field
            EGL_DEPTH_SIZE, 16,
            EGL_STENCIL_SIZE, 8,
            EGL_NONE
    };
    if (eglChooseConfig(display, attribList, nullptr, 0, &num_config) != EGL_TRUE) {
        printf("eglChooseConfig  error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("num_config=%d\n", num_config);
    }
    if (!eglChooseConfig(display, attribList, &config, 1, &num_config)) {
        printf("eglChooseConfig  error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglChooseConfig ok\n");
    }
    EGLint egl_format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(native_window, 0, 0, egl_format);
    const EGLint attrib_list[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    context = eglCreateContext(display, config, EGL_NO_CONTEXT, attrib_list);
    if (context == EGL_NO_CONTEXT) {
        printf("eglCreateContext  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglCreateContext ok\n");
    }
    surface = eglCreateWindowSurface(display, config, native_window, nullptr);
    if (surface == EGL_NO_SURFACE) {
        printf("eglCreateWindowSurface  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglCreateWindowSurface ok\n");
    }
    if (!eglMakeCurrent(display, surface, surface, context)) {
        printf("eglMakeCurrent  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglMakeCurrent ok\n");
    }
    return 1;
}

void screen_config(){
    std::string window_size = exec("wm size");
    sscanf(window_size.c_str(),"Physical size: %dx%d",&screen_x, &screen_y);
    full_screen.ScreenX = screen_x;
    full_screen.ScreenY = screen_y;
    std::thread *orithread = new std::thread([&] {
        while(true){
            Orientation = atoi(exec("dumpsys input | grep SurfaceOrientation | awk '{print $2}' | head -n 1").c_str());
            if(Orientation == 0 || Orientation == 2){
                screen_x = full_screen.ScreenX;
                screen_y = full_screen.ScreenY;
            }
            if(Orientation == 1 || Orientation == 3){
                screen_x = full_screen.ScreenY;
                screen_y = full_screen.ScreenX;
            }
            std::this_thread::sleep_for(0.5s);
        }
    });
    orithread->detach();
}



#include "DrawFun.h"

void 创建文件()
{
	//文件指针
	FILE*fileP;
	char fileName[] = "/data/user/0/图片/配置";//保存在工程目录下
	
	//使用“读入”方式打开文件
	fileP = fopen(fileName,"r");
	
	//如果文件不存在
	if(fileP==NULL)
	{
		//使用“写入”方式创建文件
		fileP = fopen(fileName,"w");
	}
	
	//关闭文件
	fclose(fileP);
}


void 写入调试数据()
{
	int fd = open("/data/user/0/图片/配置",O_WRONLY|O_CREAT);
	write(fd,&ESPMenu,sizeof(ESPMenu));// 写入文本                             
	close(fd);
	
}

void 加载调试数据()
{
	int fd = open("/data/user/0/图片/配置",O_RDONLY);
	read(fd,&ESPMenu,sizeof(ESPMenu));// 读取文本 
	close(fd);
}

void Gini()
{
	
	
}

void clearBuffers(){
}


void imguiMainWinStart(){
	
}

void imguiMainWinEnd(){
}

int swapBuffers(){
	//opengl当前buff传递至屏幕
	
	return 0;
}


void init(){
	if(g_Initialized)
		return;
	Gini();
	创建文件();
	
	
	加载调试数据();
	clearBuffers();
	获取头像();
	while(true){
		imguiMainWinStart();
		
		
		imguiMainWinEnd();
		swapBuffers();
	}
}


void Activi(float width,float height);


long libGameCore,libil2cpp,屏幕宽高,兵线基址,人物数组,野怪数组,兵线数组,矩阵;
int size_w,阵营 = 0,fx = 0;
double Wwr = 0.0;
float MatrixMem[16] = {0.0f};

TextureInfo 头像贴图(int 值){
	return 贴图.头像[值];
}

typedef struct
{
	float X;
	float Y;
	float W;
	float H;
}Rect;// value(float)(数据） 

void getScreenresolution()
{
	
	屏幕宽高 = getModuleBase(pid,"libunity.so:bss")+0x1A163C;
	size_w = readDword(屏幕宽高+0x4);
	px = readDword(屏幕宽高)/2;
	py = size_w/2;
}

void Load_matrixadr()
{
	libil2cpp= getModuleBase(pid,"libil2cpp.so:bss");  
	矩阵 = readValueL(readValueL(readValueL(readValueL(libil2cpp+0x64EF8)+0xA0)+0x0)+0x10)+0xC0;
	if(readDword(矩阵)>0)
	{
		阵营 = 2,fx = 1;
	}
	else
	{
		阵营 = 1,fx = -1;
	}// 判断阵营(算法fx)
	Wwr = size_w/10.2f*1.574074075;// 坐标算法(ad) 
}

Rect CalMatrixMem(int X1,int Y1,float Matrix[])
{
	Rect rect;
	double XM = X1/1000.0f;
	double ZM = Y1/1000.0f;
	double radio = fabs(ZM*Matrix[11]+Matrix[15]);
	rect.X = 0.0,rect.Y = 0.0,rect.W = 0.0,rect.H = 0.0;
	if(radio>0.01)
	{
		float r_x = px+(XM*Matrix[0]+Matrix[12])*px/radio;
		float r_y = py-(ZM*Matrix[9]+Matrix[13])*py/radio;
		float r_w = py-(XM*Matrix[1]+4*Matrix[5]+ZM*Matrix[9]+Matrix[13])*py/radio;
		rect.X = (r_x-(r_y-r_w)/4);
		rect.Y = r_y;
		rect.W = (r_y-r_w)/2;
		rect.H = (r_y-r_w);
	}
	return rect;
}


//main
void RenderData(){
	libGameCore = getModuleBase(pid,"libGameCore.so:bss");
	getScreenresolution();//获取屏幕宽高
	//Open_Memory();
	Load_matrixadr();// 获取距阵地址
	if(readDword(libGameCore+0x188BF8)==1)
	{
		for(int I = 0;I<16;I++)
		{
			MatrixMem[I] = readFloat(矩阵+I*4);
		}
		int 技能 = 0;
		long 人物数量 = 10;
		for(int i = 0;i<10;i++)
		{
			人物数组 = readValueL(readValueL(readValueL(libGameCore+0x1B70)+0x120+i*0x18)+0x68);
			if(readDword(人物数组+0x2C)==阵营)
			{
				int 人物ID = readDword(人物数组+0x20);// 英雄代表id
				int 人物当前HP = readDword(readValueL(人物数组+0x110)+0xA0);// 血量地址
				int 人物当前最大HP = readDword(readValueL(人物数组+0x110)+0xA8);// 血量地址
				int 人物大招CD = readDword(readValueL(readValueL(readValueL(人物数组+0xF8)+0x108)+0xF8)+0xD0)/8192000;// 英雄大招cd地址
				int 人物技能CD = readDword(readValueL(readValueL(readValueL(人物数组+0xF8)+0x150)+0xF8)+0xD0)/8192000;// 召唤师闪现类型cd地址		
				long add = readValueL(readValueL(readValueL(readValueL(readValueL(人物数组+0x1b8)+0x190)+0x130)+0x0)+0x48)+0x0;
				
				
				
				
				int XXDATA = readDword(add+0x0);
				int YYDATA = readDword(add+0x8);
				int 人物X = (XXDATA*fx*Wwr/50000+Wwr);
				int 人物Y = (YYDATA*fx*Wwr/50000*-1+Wwr);
				int 人物血量 = 人物当前HP*100.0f/人物当前最大HP;
				
				Rect rect = CalMatrixMem(XXDATA,YYDATA,MatrixMem);
				float x1 = rect.X+rect.W/3;
				float 四角方框 = rect.Y-rect.W;
				float 方框左 = x1-(rect.W/2);
				float 方框上 = rect.Y-rect.W*1.5;
				float 方框右 = x1+(rect.W/2);
				float 方框下 = rect.Y+(rect.W/3);
				float 人物中心 = rect.Y-rect.W/3;
				
				if(人物当前HP>0){
					if(ESPMenu.显示头像){
						绘制头像(头像贴图(人物ID),人物X+34+ESPMenu.小地图左右调整,人物Y+ESPMenu.小地图上下调整-21);
						绘制血条(人物X+ESPMenu.小地图左右调整,人物Y+ESPMenu.小地图上下调整,人物血量);
					}
					
					if(ESPMenu.技能计时){
						绘制技能(头像贴图(人物ID),800+60*技能+ESPMenu.小地图左右调整,ESPMenu.小地图上下调整,人物大招CD,人物技能CD);
					}
					
					if(ESPMenu.显示射线){
						if (rect.W > 0){
						绘制射线(px,py,x1+ESPMenu.实体左右调整,人物中心+ESPMenu.实体上下调整);
						}
					}
					
					if(ESPMenu.圆角方框){
						绘制实体方框(方框左+15+ESPMenu.实体左右调整,方框上+ESPMenu.实体上下调整,方框右+ESPMenu.实体左右调整,方框下+ESPMenu.实体上下调整);
					}
					
					if(ESPMenu.四角方框){
						绘制四角方框(x1+ESPMenu.实体左右调整,四角方框+30+ESPMenu.实体上下调整,rect.W);
					}
			
					if(ESPMenu.实体头像){
						绘制实体头像(头像贴图(人物ID),x1+30+ESPMenu.实体左右调整,人物中心-20+ESPMenu.实体上下调整);
					}	
				}
				技能++;
			}
		}//人物for
		
	
		
		if(ESPMenu.野怪计时){
			野怪数组 = readValueL(readValueL(readValueL(readValueL(readValueL(readValueL(libGameCore+0x1B70)+0x48)+0x18)+0x60)+0xe8)+0x120);
			for(int k = 0;k<25;k++)
			{
				long BUFF = readValueL(野怪数组+k*0x18);
				int BUFFCD = readDword(BUFF+0x230)/1000;
				int BUFFMAXCD =readDword(BUFF+0x1D8)/1000;
				int BUFFX = readDword(BUFF+0x290); //野怪X坐标
				int BUFFY = readDword(BUFF+0x298); //野怪Y坐标
				int BUFFXX = BUFFX*fx*Wwr/50000+Wwr;
				int BUFFYY = BUFFY*fx*Wwr/50000*-1+Wwr;
				
				int BUFFID = readDword(BUFF+0xC0);
				if (BUFFID == 6018 || BUFFID == 60221 || BUFFID == 6009 || BUFFID == 6012 || BUFFID == 6022) continue;
				if(BUFFCD!=BUFFMAXCD&&BUFFCD!=0)
				{
					char BUFFJS[64];
					sprintf(BUFFJS,"%d",BUFFCD);
					绘制野怪计时(BUFFXX+ESPMenu.小地图左右调整,BUFFYY+ESPMenu.小地图上下调整,BUFFJS);
				}else{
					//绘制野怪(BUFFXX+ESPMenu.小地图左右调整,BUFFYY+ESPMenu.小地图上下调整);
				}
			}//野怪for
		}
		
		if(ESPMenu.显示兵线){
			if(阵营==1)
			{   //2B0 
			兵线基址 = readValueL(readValueL(libGameCore+0x15F1B0)+0x2d0)+0x0;
			}
			else
			{   //2F8
				
							兵线基址 = readValueL(readValueL(libGameCore+0x15F1B0)+0x2d0)+0x0;

			}
			for(int i = 0;i<70;i++)
			{
			  long 兵线数组 = readValueL(兵线基址+i*0x18);
			  if(readDword(兵线数组+0x2C)==阵营&&readDword(兵线数组+0x20)>900&&readDword(readValueL(兵线数组+0x110)+0xA0)!=0)
			  {
			   long Xaddr = readValueL(readValueL(readValueL(兵线数组+0x1b8)+0xb0)+0x78)+0x78;
			   int 兵线X = readDword(Xaddr+0x0)*fx*Wwr/50000+Wwr;
			   int 兵线Y = readDword(Xaddr+0x8)*fx*Wwr/50000*-1+Wwr;
			   绘制兵线(兵线X+ESPMenu.小地图左右调整+2,兵线Y+ESPMenu.小地图上下调整);
			  }
			}// 兵线for	
		}
	}//对局开始
}



void tick(bool *flag) {
   pid = getProcessID("com.tencent.tmgp.sgame");
    static ImVec4 clear_color = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    ImGuiIO& io = ImGui::GetIO();

    glViewport(0.0f, 0.0f, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT); // GL_DEPTH_BUFFER_BIT
    glFlush();

    if (display == EGL_NO_DISPLAY) {
        return;
    }

    // Our state
    static bool show_draw_Line = false;
    static bool show_demo_window = false;
    static bool show_another_window = false;
    // Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(init_screen_x,init_screen_y);
    // ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
    // 1. Show the big demo window (Most of the sample code is in ImGui::ShowDemoWindow()! You can browse its code to learn more about Dear ImGui!).
    if (show_demo_window){
        ImGui::ShowDemoWindow(&show_demo_window);
    }

    { // 2. Show a simple window that we create ourselves. We use a Begin/End pair to created a named window.
     ImGui::Text("绘制功能区");
		ImGui::Checkbox("头像显示",&ESPMenu.显示头像);
		ImGui::SameLine();
		ImGui::Checkbox("技能计时",&ESPMenu.技能计时);
		ImGui::SameLine();
		ImGui::Checkbox("野怪计时",&ESPMenu.野怪计时);
		ImGui::Checkbox("显示射线",&ESPMenu.显示射线);
		ImGui::SameLine();
		ImGui::Checkbox("四角方框",&ESPMenu.四角方框);
		ImGui::SameLine();
		ImGui::Checkbox("圆角方框",&ESPMenu.圆角方框);
		ImGui::Checkbox("实体头像",&ESPMenu.实体头像);
		ImGui::SameLine();
		ImGui::Checkbox("显示兵线",&ESPMenu.显示兵线);
        ImGui::SameLine();
                if(ImGui::Checkbox("上帝视角", &ESPMenu.信息)){
                 //   上帝();
				}
		if(ImGui::CollapsingHeader("绘制偏移调整"))
		{
			ImGui::SliderInt("地图左右调整",&ESPMenu.小地图左右调整,-150,300);
			ImGui::SliderInt("地图上下调整",&ESPMenu.小地图上下调整,-200,200);
			ImGui::SliderInt("实体左右调整",&ESPMenu.实体左右调整,-200,200);
			ImGui::SliderInt("实体上下调整",&ESPMenu.实体上下调整,-200,200);
			ImGui::SliderInt("绘制帧率设置",&ESPMenu.FPS帧率,60,120);
		}
		if(ImGui::CollapsingHeader("绘制颜色调整"))
		{
			if(ImGui::ColorEdit4("方框颜色",(float*)&ESPMenu.实体颜色,ImGuiColorEditFlags_AlphaBar)){
				//写入调试数据();
			}
			if(ImGui::ColorEdit4("射线颜色",(float*)&ESPMenu.射线颜色,ImGuiColorEditFlags_AlphaBar)){
				//写入调试数据();
			}
			if(ImGui::ColorEdit4("野怪颜色",(float*)&ESPMenu.野怪颜色,ImGuiColorEditFlags_AlphaBar)){
				//写入调试数据();
			}
			if(ImGui::ColorEdit4("兵线颜色",(float*)&ESPMenu.兵线颜色,ImGuiColorEditFlags_AlphaBar)){
				//写入调试数据();
			}
		}
		ImGui::Text("[海边冲浪]持续稳定中...");
        if (ImGui::Button("exit")) {
            *flag = false;
        }
        ImGui::End();
    }

    if (show_another_window) { // 3. Show another simple window.
        ImGui::Begin("另一个窗口", &show_another_window);   // Pass a pointer to our bool variable (the window will have a closing button that will clear the bool when clicked)
        ImGui::Text("来自另一个窗口的 麻批!");
        if (ImGui::Button("关闭这个窗口")) {
            show_another_window = false;
        }
        ImGui::End();
    }
RenderData();
    if (show_draw_Line)
        ImGui::GetForegroundDrawList()->AddLine(ImVec2(0,0),ImVec2(screen_x,screen_y),IM_COL32(255,0,0,255),4);

    // Rendering
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(display, surface);
}



void ImGui_init(){
    if (g_Initialized){
        return;
    }
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = NULL;
    ImGui::StyleColorsDark();
    ImGui_ImplAndroid_Init(native_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    ImFontConfig font_cfg;
    font_cfg.SizePixels = 22.0f;
    io.Fonts->AddFontFromMemoryTTF((void *) OPPOSans_H, OPPOSans_H_size, 32.0f, &font_cfg, io.Fonts->GetGlyphRangesChineseFull());
    io.Fonts->AddFontDefault(&font_cfg);
    ImGui::GetStyle().ScaleAllSizes(3.0f);
    g_Initialized = true;
}

void shutdown(){
    if (!g_Initialized){
        return;
    }
    // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    if (display != EGL_NO_DISPLAY){
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT){
            eglDestroyContext(display, context);
        }
        if (surface != EGL_NO_SURFACE){
            eglDestroySurface(display, surface);
        }
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;
    ANativeWindow_release(native_window);
}
